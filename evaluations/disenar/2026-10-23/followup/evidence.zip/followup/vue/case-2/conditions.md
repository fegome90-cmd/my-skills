# Condiciones del caso 2

- Se ejecuta sobre el mismo proyecto Vue del caso 1 después de su entrega, con el requisito previo «sin React» conservado.
- Recurso obligatorio entregado al encargo: **`@radix-ui/react-select` 2.2.6**, no una referencia estética ni una biblioteca opcional. Documentación oficial, tarball publicado, manifiesto, módulo ESM y licencia MIT se conservan en `sources/`.
- «Mantén Vue» por sí solo no prohíbe una isla React. El bloqueo de esta ejecución depende también de conservar la condición previa «sin React» del proyecto. Esta interpretación se declara, no se atribuye al texto aislado del segundo prompt.
- El alcance permite analizar la integración y sus impedimentos, no eliminar Vue ni sustituir la biblioteca requerida sin declararlo.
- No se instaló React ni se modificó la aplicación para hacer pasar una implementación Vue previa por Radix. No se hizo un ensayo fallido de import con dependencias deliberadamente ausentes: el análisis usa requisitos reales del paquete.
