# Decisiones del caso 2

- Mantener intacto el proyecto Vue y el selector entregado en el caso 1. Su permanencia no se presenta como integración de Radix.
- Dar por completado el análisis y marcar **BLOCKED** la integración directa bajo las condiciones actuales.
- Base técnica: el manifiesto exacto de `@radix-ui/react-select` 2.2.6 declara peers obligatorios `react` y `react-dom` con rango `^16.8 || ^17.0 || ^18.0 || ^19.0 || ^19.0.0-rc`. Los peers de tipos son opcionales; los runtimes no lo son. El módulo real importa ambos runtimes y `react/jsx-runtime` y utiliza APIs React.
- La documentación oficial muestra componentes React con JSX y `React.forwardRef`. Esa API no es un componente Vue ni un plugin para `app.use()`.
- No concluir que una aplicación Vue jamás puede usar una biblioteca React. Una isla React con `createRoot`, un adaptador Vue, sincronización explícita de props/eventos y desmontaje sería técnicamente posible manteniendo Vue como host, pero incorporaría React y ReactDOM. Esa vía contradice la restricción previa «sin React», por lo que no se implementa silenciosamente.
- No cambiar por Radix Vue/Reka UI ni por el selector nativo del caso 1 y llamarlo Radix React Select. Cambiar la biblioteca o permitir runtimes React sería una decisión de requisitos distinta.
- No se necesita modificar fuentes o instalar peers para demostrar este conflicto de contrato. Se preserva la evidencia suficiente en lugar de añadir una integración aparente.
