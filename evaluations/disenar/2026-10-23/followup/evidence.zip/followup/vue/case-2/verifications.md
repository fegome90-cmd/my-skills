# Verificaciones del caso 2

Estado del análisis: **COMPLETO**. Estado de la integración requerida: **BLOCKED**.

Análisis reproducible: `python3 scripts/check-compatibility.py`; resultados en `evidence/compatibility-results.json`. Este script toma hashes reales antes y después de leer requisitos y módulo, sin modificar el proyecto.

- **PASS · lectura de fuente**: paquete npm `@radix-ui/react-select` 2.2.6 descargado; nombre, versión y peers cotejados. El módulo oficial importa React/ReactDOM y `react/jsx-runtime`. Evidencia: `sources/radix-package-original.json`, `sources/radix-index-original.mjs` y check `radix-react-requirement`.
- **PASS · integridad**: tarball conservado coincide con SHA-512 `dist.integrity` del registro. `evidence/download-integrity.json`.
- **PASS · documentación primaria**: documentación oficial de Select e introducción de Radix consultada y guardada. Fuente, hora y SHA-256 en `sources/manifest.json`.
- **PASS · preservación**: hashes del proyecto antes y después del análisis de integración idénticos, en `evidence/case-2-before-hashes.json` y `evidence/case-2-after-hashes.json`.
- **PASS · fuente activa**: Vue y su selector continúan sin imports React/Radix ni CDN; no se presenta eso como una integración satisfactoria.
- **BLOCKED · integración**: requerir React/ReactDOM contradice la condición previa de proyecto sin React. No se instaló un recurso alternativo para ocultar el conflicto.
- **NOT_RUN · montaje híbrido React/Vue**: no autorizado dentro de la condición vigente y no necesario para el análisis del impedimento.
- **BLOCKED · visual/teclado**: acceso del navegador al fixture impedido; no se utilizó otra superficie.
