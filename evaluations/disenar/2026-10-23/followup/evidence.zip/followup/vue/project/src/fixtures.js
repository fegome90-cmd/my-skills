// Synthetic options for this local demonstration; no service is connected.
export const regularOptions = Object.freeze([
  { value: 'weekly', label: 'Resumen semanal · Lunes' },
  { value: 'daily', label: 'Resumen diario · Días laborables' },
  { value: 'manual', label: 'Solo cuando lo solicite' },
  { value: 'instant', label: 'En tiempo real · Próximamente', disabled: true }
]);
export const longOptions = Object.freeze([
  { value: 'weekly', label: 'Resumen semanal para el equipo de investigación, coordinación y seguimiento de proyectos internacionales — Bogotá, São Paulo y 東京' },
  { value: 'daily', label: 'Diario' },
  { value: 'manual', label: 'Solo cuando lo solicite' }
]);
