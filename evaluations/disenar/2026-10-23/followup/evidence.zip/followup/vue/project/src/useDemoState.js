import { computed, ref } from '../vendor/vue.esm-browser.prod.js';
import { regularOptions, longOptions } from './fixtures.js';

export const demoModes = ['ready', 'loading', 'empty', 'error', 'disabled', 'long'];

// Fixture controller: local state, no network requests. Consumers own lifecycle cleanup.
export function createDemoState(initialMode = 'ready', retryDelay = 850) {
  const mode = ref(demoModes.includes(initialMode) ? initialMode : 'ready');
  const selected = ref('');
  let pendingTimer;
  const status = computed(() => mode.value === 'loading' ? 'loading' : mode.value === 'error' ? 'error' : 'ready');
  const options = computed(() => mode.value === 'empty' || mode.value === 'loading' || mode.value === 'error' ? [] : mode.value === 'long' ? longOptions : regularOptions);
  const selectedLabel = computed(() => [...regularOptions, ...longOptions].find(option => option.value === selected.value)?.label || 'Aún no has elegido una opción.');
  function setMode(next) {
    if (!demoModes.includes(next)) return;
    clearTimeout(pendingTimer);
    mode.value = next;
    // A mode changes only availability. A valid prior value survives and returns when ready.
  }
  function retry() {
    setMode('loading');
    pendingTimer = setTimeout(() => { mode.value = 'ready'; }, retryDelay);
  }
  function reset() { selected.value = ''; }
  function dispose() { clearTimeout(pendingTimer); }
  return { mode, status, options, selected, selectedLabel, setMode, retry, reset, dispose };
}
