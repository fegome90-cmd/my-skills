import { computed } from '../../vendor/vue.esm-browser.prod.js';
import UiField from '../primitives/UiField.js';

// Integrable Vue component. modelValue + update:modelValue are its v-model contract.
export default {
  name: 'OptionSelector',
  components: { UiField },
  props: {
    id: { type: String, required: true },
    label: { type: String, required: true },
    modelValue: { type: String, default: '' },
    options: { type: Array, default: () => [] },
    status: { type: String, default: 'ready', validator: value => ['ready', 'loading', 'error'].includes(value) },
    errorMessage: { type: String, default: 'No pudimos cargar las opciones.' },
    disabled: { type: Boolean, default: false }
  },
  emits: ['update:modelValue', 'retry'],
  setup(props) {
    const empty = computed(() => props.status === 'ready' && props.options.length === 0);
    const unavailable = computed(() => props.disabled || props.status !== 'ready' || empty.value);
    const placeholder = computed(() => {
      if (props.status === 'loading') return 'Cargando opciones…';
      if (props.status === 'error') return 'Opciones no disponibles';
      if (empty.value) return 'No hay opciones disponibles';
      return 'Elige una opción';
    });
    return { empty, unavailable, placeholder };
  },
  template: `
    <UiField :id="id" :label="label">
      <template #default="{ inputId, describedBy }">
        <select
          class="ui-input option-select"
          :id="inputId"
          :value="options.some(option => option.value === modelValue) ? modelValue : ''"
          :disabled="unavailable"
          :aria-describedby="describedBy"
          :aria-busy="status === 'loading' ? 'true' : 'false'"
          @change="$emit('update:modelValue', $event.target.value)"
        >
          <option value="" disabled>{{ placeholder }}</option>
          <option v-for="option in options" :key="option.value" :value="option.value" :disabled="option.disabled">{{ option.label }}</option>
        </select>
      </template>
      <template #hint>
        <div class="selector-feedback" aria-live="polite" aria-atomic="true">
          <p v-if="status === 'loading'" class="feedback-line"><span class="loading-dot" aria-hidden="true"></span>Estamos preparando las opciones.</p>
          <p v-else-if="status === 'error'" class="feedback-line error-text"><span aria-hidden="true">!</span>{{ errorMessage }}</p>
          <p v-else-if="empty" class="feedback-line">Todavía no hay opciones para este equipo.</p>
          <p v-else-if="disabled">La selección está deshabilitada temporalmente.</p>
          <p v-else>Elige el ritmo que mejor se adapta a tu equipo.</p>
        </div>
        <button v-if="status === 'error'" class="retry-button" type="button" @click="$emit('retry')">Reintentar carga</button>
      </template>
    </UiField>`
};
