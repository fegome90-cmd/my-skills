import UiPanel from './primitives/UiPanel.js';
import OptionSelector from './components/OptionSelector.js';
import { onUnmounted } from '../vendor/vue.esm-browser.prod.js';
import { createDemoState } from './useDemoState.js';

export default {
  name: 'App',
  components: { UiPanel, OptionSelector },
  setup() {
    const requestedMode = new URLSearchParams(window.location.search).get('state') || 'ready';
    const demo = createDemoState(requestedMode);
    onUnmounted(demo.dispose);
    return {
      ...demo,
      modes: [
        { value: 'ready', label: 'Listo' }, { value: 'loading', label: 'Carga' },
        { value: 'empty', label: 'Vacío' }, { value: 'error', label: 'Error' },
        { value: 'disabled', label: 'Deshabilitado' }, { value: 'long', label: 'Texto largo' }
      ]
    };
  },
  template: `
    <div class="page-shell">
      <header class="site-header"><a class="wordmark" href="./">ruta<span>·</span></a><span class="site-label">Tu espacio de trabajo</span></header>
      <main class="main-content">
        <p class="eyebrow">Configuración / Preferencias</p>
        <h1>A tu ritmo.</h1>
        <p class="page-intro">Menos ruido, más claridad. Elige cuándo quieres recibir las novedades de tu equipo.</p>
        <UiPanel title="Novedades de tu equipo" eyebrow="01 — Comunicación">
          <template #intro><p>Encuentra un momento que funcione para ti.</p></template>
          <OptionSelector
            id="digest-frequency"
            label="Frecuencia del resumen"
            v-model="selected"
            :options="options"
            :status="status"
            :disabled="mode === 'disabled'"
            error-message="La carga falló. Vuelve a intentarlo."
            @retry="retry"
          />
          <div class="selection-summary" aria-live="polite">
            <span class="summary-caption">Tu elección</span>
            <p data-testid="selection-value">{{ selected ? (mode === 'long' ? options.find(option => option.value === selected)?.label || selectedLabel : selectedLabel) : 'Aún no has elegido una opción.' }}</p>
            <span v-if="selected && (status !== 'ready' || mode === 'empty')" class="retained-note">Conservamos tu elección mientras las opciones no están disponibles.</span>
          </div>
          <template #footer>
            <div class="panel-footer-row"><span>Se conserva solo durante esta sesión.</span><button type="button" class="text-button" :disabled="!selected" @click="reset">Restablecer</button></div>
          </template>
        </UiPanel>
        <aside class="demo-controls" aria-label="Escenarios de la demostración">
          <div class="demo-heading"><h2>Explora los estados</h2><span class="fixture-badge">Demo local</span></div>
          <p>Estos datos son de ejemplo. Cambia de estado para revisar el selector.</p>
          <div class="scenario-buttons" role="group" aria-label="Estado de opciones">
            <button v-for="item in modes" :key="item.value" type="button" :data-mode="item.value" :aria-pressed="mode === item.value" @click="setMode(item.value)">{{ item.label }}</button>
          </div>
          <p class="demo-note">«Carga» queda visible hasta cambiar de estado. «Reintentar carga» pasa por carga y recupera las opciones en 850 ms.</p>
        </aside>
      </main>
      <footer class="site-footer">ruta · Un espacio para trabajar con calma.</footer>
    </div>`
};
