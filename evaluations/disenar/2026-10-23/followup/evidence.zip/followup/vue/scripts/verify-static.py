from pathlib import Path
import subprocess, json, re, hashlib, datetime, argparse

base = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser(description='Verify fixture syntax, local imports and specified contrast pairs without a browser.')
parser.add_argument('--skill', type=Path, help='Path to the disenar skill directory. Defaults to the relative design-testing repository layout.')
args = parser.parse_args()
skill_directory = args.skill.expanduser().resolve() if args.skill else (base / '../../../../../skills/disenar').resolve()
contrast_script = skill_directory / 'scripts' / 'contrast.py'
if not contrast_script.is_file():
    parser.error('Contrast helper not found. Supply --skill PATH pointing to the disenar skill directory.')
checks = []
for folder in ['project', 'initial-snapshot']:
    for file in sorted((base / folder).rglob('*.js')):
        result = subprocess.run(['node', '--check', str(file)], text=True, capture_output=True)
        checks.append({'criterion': 'ECMAScript syntax', 'file': str(file.relative_to(base)), 'status': 'PASS' if result.returncode == 0 else 'FAIL', 'exit_code': result.returncode, 'output': result.stderr})
        code = file.read_text()
        # Modules in this fixture use explicit relative static imports; vendor bundle is self-contained.
        for specifier in re.findall(r"from\s*['\"]([^'\"]+)['\"]", code):
            local = specifier.startswith('.') and (file.parent / specifier).resolve().is_file()
            checks.append({'criterion': 'Static import resolves locally without CDN', 'file': str(file.relative_to(base)), 'specifier': specifier, 'status': 'PASS' if local else 'FAIL'})
    for file in sorted((base / folder).rglob('*.css')):
        for specifier in re.findall(r"@import\s+url\(['\"]([^'\"]+)['\"]\)", file.read_text()):
            local = specifier.startswith('.') and (file.parent / specifier).resolve().is_file()
            checks.append({'criterion': 'Stylesheet import resolves locally', 'file': str(file.relative_to(base)), 'specifier': specifier, 'status': 'PASS' if local else 'FAIL'})
    file = base / folder / 'index.html'
    for specifier in re.findall(r'(?:src|href)="(\.[^"]+)"', file.read_text()):
        checks.append({'criterion': 'Entrypoint asset exists', 'file': str(file.relative_to(base)), 'specifier': specifier, 'status': 'PASS' if (file.parent / specifier).is_file() else 'FAIL'})
for foreground, background, use in [('#18352c','#ffffff','Main card text'),('#53635a','#ffffff','Card helper text'),('#53635a','#f3f4ee','Page helper text'),('#ffffff','#18352c','Selected scenario button'),('#166044','#ffffff','Retry button text'),('#9c302b','#ffffff','Error text')]:
    result = subprocess.run(['python3', str(contrast_script),foreground,background,'--threshold','4.5'],text=True,capture_output=True)
    checks.append({'criterion':'Contrast for specified opaque sRGB pair, threshold 4.5','use':use,'foreground':foreground,'background':background,'status':'PASS' if result.returncode==0 else 'FAIL','exit_code':result.returncode,'output':result.stdout.strip(),'limit':'Calculation only; no rendered text/background measurement or full accessibility assessment.'})
report = {'generated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'coverage':'Syntax, local static dependency paths, narrow opaque color calculations; no browser.','contrast_helper':str(contrast_script),'contrast_helper_source':'--skill' if args.skill else 'relative repository layout'}
(base/'evidence/static-verification-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
summary = {status:sum(c['status']==status for c in checks) for status in ['PASS','FAIL']}
print(json.dumps(summary))
raise SystemExit(1 if summary['FAIL'] else 0)
