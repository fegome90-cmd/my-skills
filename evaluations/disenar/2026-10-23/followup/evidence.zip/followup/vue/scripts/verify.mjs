import assert from 'node:assert/strict';
import { readFile, readdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import * as Vue from '../project/vendor/vue.esm-browser.prod.js';
import UiField from '../project/src/primitives/UiField.js';
import UiPanel from '../project/src/primitives/UiPanel.js';
import OptionSelector from '../project/src/components/OptionSelector.js';
import App from '../project/src/App.js';
import { createDemoState, demoModes } from '../project/src/useDemoState.js';

const base = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const checks = [];
function check(id, criterion, fn) {
  try { fn(); checks.push({ id, criterion, status: 'PASS', method: `${process.version} + local Vue runtime; no browser` }); }
  catch (e) { checks.push({ id, criterion, status: 'FAIL', error: e.message }); }
}
function hash(data) { return createHash('sha256').update(data).digest('hex'); }

check('runtime', 'The vendored runtime executes as Vue 3.5.22 and exposes real reactive refs.', () => {
  assert.equal(Vue.version, '3.5.22'); assert.equal(typeof Vue.createApp, 'function');
  const value = Vue.ref(2); assert.equal(Vue.isRef(value), true);
  const doubled = Vue.computed(() => value.value * 2); assert.equal(doubled.value, 4); value.value = 7; assert.equal(doubled.value, 14);
});
for (const component of [UiField, UiPanel, OptionSelector, App]) {
  check(`compile-${component.name}`, `${component.name} template compiles with the shipped Vue compiler (identity HTML-entity decoder for Node; templates contain no entity references).`, () => {
    const errors = [];
    const render = Vue.compile(component.template, { decodeEntities: raw => raw, onError: error => errors.push(error.message) });
    assert.deepEqual(errors, []); assert.equal(typeof render, 'function');
  });
}

check('selector-unavailability', 'Loading, error, empty and disabled states make the select unavailable; normal options allow use.', () => {
  const props = Vue.reactive({ options: [{ value: 'x', label: 'X' }], status: 'ready', disabled: false });
  const selector = OptionSelector.setup(props);
  assert.equal(selector.unavailable.value, false);
  props.status = 'loading'; assert.equal(selector.unavailable.value, true); assert.match(selector.placeholder.value, /Cargando/);
  props.status = 'error'; assert.equal(selector.unavailable.value, true); assert.match(selector.placeholder.value, /no disponibles/);
  props.status = 'ready'; props.options = []; assert.equal(selector.empty.value, true); assert.equal(selector.unavailable.value, true);
  props.options = [{ value: 'x', label: 'X' }]; props.disabled = true; assert.equal(selector.unavailable.value, true);
});

check('scenarios-and-preservation', 'All six demo modes share the same state/controller; selection survives temporary unavailability and reset works.', () => {
  const state = createDemoState('ready'); state.selected.value = 'weekly';
  for (const mode of demoModes) { state.setMode(mode); assert.equal(state.mode.value, mode); assert.equal(state.selected.value, 'weekly'); }
  state.setMode('empty'); assert.equal(state.options.value.length, 0); assert.equal(state.status.value, 'ready');
  state.setMode('error'); assert.equal(state.options.value.length, 0); assert.equal(state.status.value, 'error');
  state.setMode('long'); assert.ok(state.options.value[0].label.length > 100);
  state.setMode('bogus'); assert.equal(state.mode.value, 'long');
  state.reset(); assert.equal(state.selected.value, ''); state.dispose();
});

const retry = createDemoState('error', 12);
retry.retry();
check('retry-immediate', 'Retry enters loading synchronously.', () => assert.equal(retry.status.value, 'loading'));
await new Promise(resolve => setTimeout(resolve, 35));
check('retry-completes', 'Retry returns to ready with options after its local timer.', () => {
  assert.equal(retry.status.value, 'ready'); assert.equal(retry.options.value.length, 4);
});
retry.retry(); retry.setMode('empty');
await new Promise(resolve => setTimeout(resolve, 35));
check('retry-cancellation', 'Changing scenario cancels an outstanding retry so it does not overwrite the new state.', () => assert.equal(retry.mode.value, 'empty'));
retry.retry(); retry.dispose();
await new Promise(resolve => setTimeout(resolve, 35));
check('dispose-cancels-timer', 'Disposal cancels a retry timer (the component calls disposal on unmount).', () => assert.equal(retry.mode.value, 'loading'));

for (const primitive of ['UiField.js', 'UiPanel.js']) {
  const oldData = await readFile(path.join(base, 'initial-snapshot/src/primitives', primitive));
  const newData = await readFile(path.join(base, 'project/src/primitives', primitive));
  check(`preserve-${primitive}`, `Existing primitive ${primitive} remains byte-for-byte unchanged from the initial snapshot.`, () => assert.equal(hash(oldData), hash(newData)));
}
const radix = JSON.parse(await readFile(path.join(base, 'sources/radix-package-original.json'), 'utf8'));
const radixModule = await readFile(path.join(base, 'sources/radix-index-original.mjs'), 'utf8');
check('radix-react-requirement', 'Required Radix Select package is real and declares React/ReactDOM peer runtimes and imports.', () => {
  assert.equal(radix.name, '@radix-ui/react-select'); assert.equal(radix.version, '2.2.6');
  assert.ok(radix.peerDependencies.react); assert.ok(radix.peerDependencies['react-dom']);
  assert.match(radixModule, /import \* as React from "react"/); assert.match(radixModule, /import \* as ReactDOM from "react-dom"/);
});
async function walk(dir) {
  let found = [];
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const file = path.join(dir, entry.name);
    found = found.concat(entry.isDirectory() ? await walk(file) : [file]);
  }
  return found;
}
const appFiles = (await walk(path.join(base, 'project'))).filter(file => /\.(js|css|html|json)$/.test(file) && !file.includes('/vendor/'));
const appCode = (await Promise.all(appFiles.map(file => readFile(file, 'utf8')))).join('\n');
check('no-react-and-no-cdn', 'The active app has no React/Radix imports and no remote scripts, styles, fonts or imports.', () => {
  assert.doesNotMatch(appCode, /(?:from\s*|import\s*|src=)["'](?:react|react-dom|@radix-ui|https?:|\/\/)/);
  assert.doesNotMatch(appCode, /@import\s+(?:url\()?['"]?https?:/);
});
checks.push({ id: 'render-keyboard-layout', criterion: 'Rendered viewports, keyboard, focus, native popup and assistive technologies.', status: 'BLOCKED', method: 'No browser controlled by this worker. Coordinator reports cloud browser cannot reach localhost and policy rejected data URLs; alternate control surfaces are prohibited. No rendered or keyboard evidence exists.' });
const result = { generated_at_utc: new Date().toISOString(), node: process.version, runtime: `Vue ${Vue.version}`, coverage: 'Source integrity, real Vue runtime/compiler, reactive state and async fixture logic. No DOM mounting or browser render.', checks };
await writeFile(path.join(base, 'evidence/verification-results.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
if (checks.some(result => result.status === 'FAIL')) process.exitCode = 1;
