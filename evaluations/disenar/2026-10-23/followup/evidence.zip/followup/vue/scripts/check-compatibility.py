from pathlib import Path
import hashlib, json, datetime

base = Path(__file__).resolve().parent.parent

def snapshot(destination, note):
    rows = [{'path':str(p.relative_to(base/'project')),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted((base/'project').rglob('*')) if p.is_file()]
    report = {'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'note':note,'files':rows}
    (base/'evidence'/destination).write_text(json.dumps(report,indent=2)+'\n')
    return rows

before = snapshot('case-2-before-hashes.json', 'Actual project hashes recorded immediately before executing this compatibility analysis; no app changes are performed by the script.')
metadata = json.loads((base/'sources/radix-package-original.json').read_text())
module = (base/'sources/radix-index-original.mjs').read_text()
peers = metadata['peerDependencies']
react_required = 'react' in peers and not metadata.get('peerDependenciesMeta',{}).get('react',{}).get('optional',False)
react_dom_required = 'react-dom' in peers and not metadata.get('peerDependenciesMeta',{}).get('react-dom',{}).get('optional',False)
assert metadata['name'] == '@radix-ui/react-select' and metadata['version'] == '2.2.6'
assert react_required and react_dom_required
assert 'import * as React from "react"' in module and 'import * as ReactDOM from "react-dom"' in module
report = {
    'generated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'method':'Read exact published package metadata and module imports; do not install or execute Radix.',
    'package':metadata['name'], 'version':metadata['version'],
    'required_peer_ranges':{'react':peers['react'],'react-dom':peers['react-dom']},
    'observed_imports':['react','react-dom','react/jsx-runtime'],
    'condition_inherited_from_case_1':{'keepVue':True,'noReact':True},
    'analysis_status':'COMPLETE', 'integration_status':'BLOCKED',
    'blocker':'The required package needs React and ReactDOM; adding them violates the inherited no-React condition. Its React component API cannot be directly used as a Vue component.',
    'hybrid_note':'Keeping Vue alone does not prevent a React island. An explicit Vue-to-React adapter and both React runtimes could be developed if the no-React condition changed.',
    'replacements_made':False, 'react_installed':False, 'radix_executed':False,
    'source_hashes':{name:hashlib.sha256((base/'sources'/name).read_bytes()).hexdigest() for name in ['radix-package-original.json','radix-index-original.mjs','radix-select-docs.html']}
}
after = snapshot('case-2-after-hashes.json', 'Actual project hashes recorded immediately after this compatibility analysis. No source was modified.')
report['project_unchanged'] = before == after
assert report['project_unchanged']
(base/'evidence/compatibility-results.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'analysis':report['analysis_status'],'integration':report['integration_status'],'project_unchanged':report['project_unchanged']}))
