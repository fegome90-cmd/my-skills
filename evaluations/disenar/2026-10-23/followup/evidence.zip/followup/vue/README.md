# Forward-test Vue · 23 de octubre de 2026

Caso 1: implementación Vue entregada con verificación local de código/lógica; render e interacción **BLOCKED** por acceso del navegador. Caso 2: análisis completo; integración de Radix React Select **BLOCKED** bajo el requisito heredado «sin React».

## Abrir y editar

Desde esta carpeta:

```bash
python3 -m http.server 4186 --bind 127.0.0.1
```

Abrir `http://127.0.0.1:4186/project/`. El servidor no está en ejecución al entregar. No se publicó nada. La entrada del artefacto es `project/index.html`; el runtime, estilos y módulos se resuelven localmente, sin CDN ni instalación npm.

El snapshot anterior a los encargos está en `initial-snapshot/`, accesible con el mismo servidor. Fuentes editables en `project/src/`: componentes Vue con objetos JS, `setup()` y templates Vue; primitivas en `src/primitives/`. Vue 3.5.22 oficial y licencia MIT en `project/vendor/`.

## Controles de prueba posterior

- Selector «Frecuencia del resumen»: tres opciones utilizables y una deshabilitada; el valor aparece completo en «Tu elección».
- «Restablecer»: borra la selección. Se habilita tras elegir.
- Botones «Listo», «Carga», «Vacío», «Error», «Deshabilitado» y «Texto largo» comparten la misma instancia del selector.
- «Carga» queda fijo para inspección. «Error» muestra «Reintentar carga»: pasa a carga y vuelve a listo tras 850 ms. Elegir otro estado cancela el reintento.
- La selección se conserva al pasar por carga, vacío y error; vuelve al control al recuperar opciones.
- Rutas reproducibles: `project/?state=ready`, `?state=loading`, `?state=empty`, `?state=error`, `?state=disabled`, `?state=long`.
- Para revisión posterior: desktop 1440×900, móvil 390×844 y 320×568; Tab/Shift+Tab, selector nativo con flechas, reset, reintento, ampliación de texto, espaciado, reducción de movimiento y resumen Unicode largo. Estas pruebas están pendientes; no son resultados ejecutados.

## Evidencia

Cada caso separa prompt, condiciones, decisiones, verificaciones y límites. `case-2/integration-status.md` explica el impedimento real y la diferencia entre Vue-only e isla React. `sources/` conserva fuentes primarias y paquetes con versiones; `sources/manifest.json` registra URL y hashes. `evidence/` conserva resultados y hashes de snapshots/proyecto.

Repetir checks sin navegador:

```bash
node scripts/verify.mjs
python3 scripts/verify-static.py
python3 scripts/check-compatibility.py
```

No se accedió a rúbricas ni salidas de otros workers. No se modificaron skill, repositorios de producción o sistemas externos, ni se publicaron archivos o commits.
