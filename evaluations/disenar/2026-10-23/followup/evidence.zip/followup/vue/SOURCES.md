# Fuentes primarias y procedencia

Fuentes descargadas el 23 de octubre de 2026. `sources/manifest.json` conserva URL, tamaño, SHA-256 y fecha de cada recuperación. No se afirma que las versiones fijadas sean las últimas.

| Fuente | Uso |
|---|---|
| [Vue 3.5.22 publicado](https://registry.npmjs.org/vue/3.5.22) | Runtime oficial exacto, licencia y metadata `dist.integrity`. El tarball y la licencia original se conservan. |
| [Vue Application API](https://vuejs.org/api/application.html) | `createApp()` y `mount()`. |
| [Vue Reactivity Core](https://vuejs.org/api/reactivity-core.html) | `ref`, `computed` y actualización reactiva. |
| [Vue Form Input Bindings](https://vuejs.org/guide/essentials/forms.html) | Estado JS como fuente de verdad, `<select>` y evento change. |
| [Vue Component v-model](https://vuejs.org/guide/components/v-model.html) | Prop `modelValue` y evento `update:modelValue` para el contrato del selector. |
| [Vue Props](https://vuejs.org/guide/components/props.html) | Props unidireccionales y contrato de componente. |
| [Vue Slots](https://vuejs.org/guide/components/slots.html) | Slots con props para las primitivas de campo/contenedor. |
| [Vue Lifecycle](https://vuejs.org/api/composition-api-lifecycle.html) | `onUnmounted` y limpieza de timer. |
| [HTML Select, WHATWG](https://html.spec.whatwg.org/multipage/form-elements.html#the-select-element) | Semántica nativa del select y sus opciones. |
| [Radix Select](https://www.radix-ui.com/primitives/docs/components/select) | API React/JSX y composición de la biblioteca requerida. HTML oficial conservado. |
| [Radix Introduction](https://www.radix-ui.com/primitives/docs/overview/introduction) | Contexto de componentes React de la biblioteca. |
| [Radix React Select 2.2.6 publicado](https://registry.npmjs.org/@radix-ui/react-select/2.2.6) | Requisitos exactos, peers, módulo fuente, licencia y tarball real. |

La documentación actual puede presentar imports desde el paquete agregado `radix-ui`; el recurso del caso está fijado al paquete individual `@radix-ui/react-select` 2.2.6 y su manifiesto publicado es la evidencia autoritativa de esos peers.

No se reutilizaron assets de marca externos. «ruta» y los datos son una identidad y contenido de fixture creados para esta prueba. Se usa tipografía del sistema. Vue y Radix son MIT; avisos originales conservados. Radix no se ejecuta ni se integra en la aplicación entregada.
