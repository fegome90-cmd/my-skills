export default {
  name: 'UiPanel',
  props: { title: { type: String, required: true }, eyebrow: String },
  template: `
    <section class="ui-panel">
      <header class="ui-panel__header">
        <p v-if="eyebrow" class="eyebrow">{{ eyebrow }}</p>
        <h2>{{ title }}</h2>
        <slot name="intro"></slot>
      </header>
      <div class="ui-panel__body"><slot></slot></div>
      <footer v-if="$slots.footer" class="ui-panel__footer"><slot name="footer"></slot></footer>
    </section>`
};
