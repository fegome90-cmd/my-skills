import UiPanel from './primitives/UiPanel.js';
import UiField from './primitives/UiField.js';
import { ref } from '../vendor/vue.esm-browser.prod.js';
export default {
  name: 'App', components: { UiPanel, UiField },
  setup() { return { name: ref('') }; },
  template: `
    <div class="page-shell">
      <header class="site-header"><a class="wordmark" href="./">ruta<span>·</span></a><span class="site-label">Tu espacio de trabajo</span></header>
      <main class="main-content">
        <p class="eyebrow">Configuración / Perfil</p><h1>Hazlo tuyo.</h1>
        <p class="page-intro">Configura los detalles de tu espacio, a tu ritmo.</p>
        <UiPanel title="Preferencias de equipo" eyebrow="01 — Identidad">
          <template #intro><p>Un punto de partida para organizar tu trabajo.</p></template>
          <UiField id="team-name" label="Nombre del equipo" hint="Visible para las personas de tu espacio.">
            <template #default="{ inputId, describedBy }"><input class="ui-input" :id="inputId" :aria-describedby="describedBy" v-model="name" placeholder="Mi equipo"></template>
          </UiField>
          <template #footer><span>Los cambios se guardan en esta sesión.</span></template>
        </UiPanel>
      </main>
    </div>`
};
