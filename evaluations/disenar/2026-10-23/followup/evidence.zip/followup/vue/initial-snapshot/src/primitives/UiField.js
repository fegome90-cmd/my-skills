export default {
  name: 'UiField',
  props: {
    id: { type: String, required: true },
    label: { type: String, required: true },
    hint: String
  },
  template: `
    <div class="ui-field">
      <label class="ui-field__label" :for="id">{{ label }}</label>
      <slot :input-id="id" :described-by="id + '-hint'"></slot>
      <div :id="id + '-hint'" class="ui-field__hint"><slot name="hint">{{ hint }}</slot></div>
    </div>`
};
