# Condiciones del caso 1

- Forward-test local de desarrollo con filesystem compartido, no ciego.
- Skill aplicada: `/workspace/scratch/d17c3d8f8225/design-testing/skills/disenar/SKILL.md`, con referencias pertinentes de web, encargo, auditoría y fuentes. No se modificó la skill.
- Carpeta autorizada exclusiva: la raíz `followup/vue` que contiene este documento. Sin producción, publicación, commits ni banco personal.
- Fixture preparado antes del encargo: Vue 3.5.22 real, runtime ESM con compilador empaquetado localmente, licencia MIT conservada.
- Primitivas existentes del fixture: `UiField` (etiqueta, control por slot y descripción) y `UiPanel` (cabecera, cuerpo y pie). `initial-snapshot/` contiene el proyecto antes del selector, incluido runtime y tokens.
- Edición: módulos Vue en JavaScript con objetos de componente, `setup()` y templates Vue legibles. No se necesitan SFC ni un paso de build para abrir la demo; modificar estos módulos modifica la aplicación.
- Sin React, ReactDOM, biblioteca personal, fuentes remotas ni CDN en la aplicación activa. No se instaló un navegador.
- Los datos y fallos son fixtures explícitos. No hay servicio, backend ni persistencia entre recargas.
- El navegador cloud pertenece al coordinador. Este worker no lo controla. El coordinador informó después que localhost es inaccesible y que la política rechazó URLs de datos; se conserva ese bloqueo sin eludirlo con otra superficie.
