# Decisiones del caso 1

1. Mantener Vue 3.5.22 y las dos primitivas existentes, sin alterarlas. El selector compone `UiField` y la demo compone `UiPanel`; la identidad y los tokens provienen del snapshot del propio fixture.
2. Elegir `<select>` nativo. El encargo no exige un popup personalizado; el control nativo aporta selección y teclado del navegador sin simular roles ARIA. La comprobación real de ese teclado sigue bloqueada.
3. Contrato del componente: `id`, `label`, `modelValue`, `options`, `status`, `errorMessage`, `disabled`; emite `update:modelValue` y `retry`. Los consumidores mantienen los datos y la selección.
4. Carga, error y lista vacía impiden elegir. La opción inicial describe el estado. La ayuda usa una región viva educada; el error incluye un botón real de reintento. El error es de obtención de datos y no se marca como valor inválido del usuario.
5. Conservar una selección válida durante indisponibilidad temporal, mostrarla completa debajo del control y recuperarla cuando vuelven las opciones. Mientras no hay opciones se muestra el placeholder, aunque exista una selección conservada.
6. Integrar seis escenarios en la misma demo, incluida una opción deshabilitada y texto Unicode largo por la misma prop `options`. Los botones fijan estados; el reintento usa un timer local de 850 ms. Cambiar de escenario cancela el timer. El hook `onUnmounted` limpia efectos pendientes.
7. Fijar runtime y licencia junto al código. Se descargó el paquete npm publicado y se extrajo su bundle oficial autocontenido, no una emulación de Vue. El SHA-512 del tarball coincide con `dist.integrity` del registro.
8. No construir un sistema de diseño nuevo ni registrar el componente en un banco. El único recurso externo ejecutado por la aplicación es el runtime Vue local.
