# Verificaciones del caso 1

Estado del encargo: **PARCIAL**. La implementación y los estados están entregados; la verificación renderizada y de interacción quedó bloqueada por el entorno del coordinador.

Evidencia reproducible:

- `node scripts/verify.mjs`: runtime real, compilación de los cuatro templates, estado reactivo, indisponibilidad, selección conservada, reset, recuperación, cancelación y limpieza de timers. Resultado final en `evidence/verification-results.json` y log separado.
- `python3 scripts/verify-static.py`: sintaxis ECMAScript, resolución de imports/activos locales y seis pares de contraste. Resultado en `evidence/static-verification-results.json` y log separado.
- `evidence/download-integrity.json`: SHA-512 de los paquetes publicados, comparado con metadatos npm descargados. Ambos paquetes PASS.
- `evidence/initial-snapshot-hashes.json`: snapshot anterior a implementar. Los hashes de `UiField.js` y `UiPanel.js` coinciden byte por byte con la entrega.
- Los checks de ausencia de CDN y de React comprueban la fuente activa. No equivalen a observar una carga en el navegador ni a un análisis completo de dependencias de un producto.
- **BLOCKED**: montar DOM/render, popup nativo, puntero, teclado, foco, viewport móvil, zoom, tecnologías de asistencia y rendimiento percibido. No existe captura ni prueba de interacción de este worker.

Incidencia conservada: el primer intento de compilar `App` desde el bundle de navegador en Node falló por `document is not defined`, porque el decoder de entidades HTML del compilador de navegador usa DOM. Se conserva `evidence/verification-initial.log`. La segunda ejecución usa `decodeEntities: raw => raw` solo en el harness Node: los templates no contienen referencias HTML a entidades, pero sí un operador `&&`. La aplicación y el runtime no se modificaron para esta adaptación. Este check comprueba sintaxis del template, no montaje, interpretación DOM ni procesamiento de entidades HTML.
