# Límites del caso 1

- No inspección visual ni interacción. El coordinador informó bloqueo de localhost y rechazo de la alternativa de URL de datos por la política del navegador; no se probó otra superficie.
- No afirmar conformidad WCAG global. Se calcularon seis pares sRGB opacos; faltan tamaño y geometría final del foco, contraste de estados nativos, zoom, espaciado y lectura asistiva.
- No backend, fallos reales de red ni persistencia. «Reintentar» simula una recuperación local y siempre termina con éxito salvo que se cambie de estado o se desmonte.
- El selector es de selección única. No incorpora búsqueda, multiselección ni virtualización, fuera del encargo.
- La anchura y presentación del popup nativo dependen del navegador y del sistema operativo. El texto elegido se muestra completo en el resumen, pero no se verificó el popup con texto largo.
- Fuente editable: módulos Vue de JavaScript con template; no se entregan SFC `.vue` ni un pipeline Vite. Esto es una aplicación Vue real con compilación de templates en runtime, no un simulador ni React.
- La edición y ejecución requieren servir archivos por HTTP; abrir `index.html` con `file://` puede bloquear imports de módulos. No hay dependencia de conexión exterior al servir la demo.
- El compilador de templates en runtime requiere una política CSP que permita su ejecución dinámica. La demo local no impone CSP; un entorno de producción con CSP estricta necesitaría compilar templates de antemano.
- No publicación, commits ni pruebas con personas. El servidor local de prueba se detuvo por instrucción del coordinador.
