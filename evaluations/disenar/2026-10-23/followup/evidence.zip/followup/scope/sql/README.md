# Corrección SQL

El JOIN emitía una fila por inscripción confirmada. Dos o tres inscripciones del mismo taller multiplicaban su fila en la salida. El contrato del fixture pide una fila por taller con al menos una confirmación.

`after.sql` usa `EXISTS` correlacionado: pregunta si hay una inscripción pertinente y conserva una sola fila de la tabla exterior. Los talleres 1 y 5 comparten nombre y siguen siendo registros distintos. No se agrupa por nombre ni se cambia la relación 1:N del modelo.

Resultado reproducido: `before.sql` devuelve IDs `[1,1,2,5,5,5]`; `after.sql` devuelve `[1,2,5]`, iguales al esperado. Los seis casos ejecutados cubren el fixture normal, base vacía, ninguna confirmación, ninguna inscripción, más coincidencias para un taller y eliminación de una confirmación. `results.json` registra salidas concretas y versión SQLite 3.53.1; `synthetic.sqlite` conserva los datos; `change.diff` muestra el cambio.

Reproducir: `python3 run.py`. No se aportó esquema real ni carga para evaluar rendimiento. Si el resultado deseado fuera una fila por persona o un total por taller, habría que cambiar el contrato de la consulta. Todos los datos son sintéticos y no se realizó trabajo visual.

Fuente técnica primaria consultada: [SQLite: EXISTS y subconsultas correlacionadas](https://www.sqlite.org/lang_expr.html#the_exists_operator). La documentación explica la prueba de existencia; el resultado correcto del fixture proviene de la ejecución local.
