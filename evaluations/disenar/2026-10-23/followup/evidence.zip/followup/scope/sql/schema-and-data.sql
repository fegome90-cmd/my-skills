PRAGMA foreign_keys = ON;
CREATE TABLE talleres (
  id INTEGER PRIMARY KEY,
  nombre TEXT NOT NULL
);
CREATE TABLE inscripciones (
  id INTEGER PRIMARY KEY,
  taller_id INTEGER NOT NULL REFERENCES talleres(id),
  persona TEXT NOT NULL,
  confirmada INTEGER NOT NULL CHECK (confirmada IN (0, 1))
);
-- Todos los datos son sintéticos.
INSERT INTO talleres VALUES
  (1, 'Jardín comunitario'),
  (2, 'Intercambio de oficios'),
  (3, 'Memoria del barrio'),
  (4, 'Cocina compartida'),
  (5, 'Jardín comunitario');
INSERT INTO inscripciones VALUES
  (1,1,'Persona A',1),(2,1,'Persona B',1),(3,1,'Persona C',0),
  (4,2,'Persona D',1),(5,3,'Persona E',0),
  (6,5,'Persona F',1),(7,5,'Persona G',1),(8,5,'Persona H',1);
