SELECT t.id, t.nombre
FROM talleres AS t
WHERE EXISTS (
  SELECT 1
  FROM inscripciones AS i
  WHERE i.taller_id = t.id
    AND i.confirmada = 1
)
ORDER BY t.id;
