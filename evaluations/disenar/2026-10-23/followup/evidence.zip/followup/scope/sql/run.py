"""Execute the supplied synthetic SQLite fixture and relevant boundary cases."""
from pathlib import Path
import difflib
import json
import sqlite3

ROOT = Path(__file__).parent
before = (ROOT / 'before.sql').read_text()
after = (ROOT / 'after.sql').read_text()
schema = (ROOT / 'schema-and-data.sql').read_text()

def connection():
    db = sqlite3.connect(':memory:')
    db.executescript(schema)
    return db

def rows(db, query):
    return [list(row) for row in db.execute(query)]

db = connection()
before_rows = rows(db, before)
expected = json.loads((ROOT / 'expected.json').read_text())
actual = rows(db, after)
assert actual == expected
assert len(before_rows) == 6 and len(actual) == 3
assert [r[0] for r in before_rows] == [1, 1, 2, 5, 5, 5]
# Distinct workshops sharing a name survive; no grouping by the label.
assert [r[0] for r in actual if r[1] == 'Jardín comunitario'] == [1, 5]
db.backup(sqlite3.connect(ROOT / 'synthetic.sqlite'))
checks = [{'id':'normal-1-to-many-and-same-name','status':'PASS','expected':expected,'actual':actual}]

for name, setup, expected in [
    ('empty', 'DELETE FROM inscripciones; DELETE FROM talleres;', []),
    ('no-confirmed', 'UPDATE inscripciones SET confirmada=0;', []),
    ('no-registrations', 'DELETE FROM inscripciones;', []),
    ('additional-confirmed', "INSERT INTO inscripciones VALUES (9,2,'Persona I',1),(10,2,'Persona J',1);", actual),
    ('removed-confirmation', 'UPDATE inscripciones SET confirmada=0 WHERE taller_id=1;', actual[1:]),
]:
    test = connection()
    test.executescript(setup)
    got = rows(test, after)
    assert got == expected, (name, got, expected)
    checks.append({'id':name,'status':'PASS','expected':expected,'actual':got})
    test.close()

result = {
    'sqlite_version': sqlite3.sqlite_version,
    'data':'synthetic',
    'before':before_rows,
    'after':actual,
    'cause':'The JOIN yields one row per matching confirmed registration; a workshop can match several.',
    'fix':'Correlated EXISTS filters workshops by the presence of a match without multiplying the outer rows.',
    'checks':checks,
    'limits':['No production schema/data or performance workload was supplied.','The required result is one row per workshop, not one row per participant.'],
}
(ROOT / 'results.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
(ROOT / 'change.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before.sql',tofile='after.sql')))
print(json.dumps({'sqlite_version':sqlite3.sqlite_version,'before_ids':[r[0] for r in before_rows],'after_ids':[r[0] for r in actual],'checks':len(checks),'status':'PASS'},ensure_ascii=False))
