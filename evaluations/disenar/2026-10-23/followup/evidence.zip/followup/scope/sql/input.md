# Input congelado

Petición: «Corrige este error de la consulta SQL que devuelve filas duplicadas».

Contrato añadido al fixture, antes de corregir: devolver una fila por taller que tenga al menos una inscripción confirmada. Talleres diferentes con el mismo nombre deben permanecer distintos. No necesitamos listar las personas inscritas. Se usa SQLite y datos sintéticos.

Enrutamiento de desarrollo: problema técnico de backend, sin resultado visual. `disenar` lo excluye. Resolver consulta y ejecutar casos; no diseñar interfaz, diagrama o presentación. Esto no prueba activación automática del host.
