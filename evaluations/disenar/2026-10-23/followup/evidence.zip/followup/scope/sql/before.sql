SELECT t.id, t.nombre
FROM talleres AS t
JOIN inscripciones AS i ON i.taller_id = t.id
WHERE i.confirmada = 1
ORDER BY t.id;
