# Input congelado

Petición: «Solo quiero un guion de cinco minutos sobre este contenido, con notas de exposición; todavía no diseñes diapositivas».

Contenido: explicar a voluntarios cómo preparar, realizar y cerrar un taller comunitario. No se aportan datos empíricos.

Condiciones: contenido original en español; tono directo y acogedor; solo guion y notas. Las recomendaciones son una propuesta práctica, no conclusiones de investigación. No crear diapositivas, layouts, imágenes ni componentes.

Enrutamiento de desarrollo: este encargo excluye diseño visual. La descripción de `disenar` lo deja fuera y `referencias/presentaciones.md` confirma que un guion aislado mantiene ese alcance. Se responde como redacción ordinaria. Esto no prueba activación automática del host.
