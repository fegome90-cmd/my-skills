# Guion hablado y notas de exposición

Audiencia: personas voluntarias que facilitarán un taller comunitario. Propósito: salir con una secuencia práctica para preparar, realizar y cerrar el encuentro. No requiere diapositivas.

## Apertura

**Texto hablado**

Gracias por ofrecer su tiempo. Hoy vamos a recorrer una tarea concreta: acompañar un taller comunitario desde la preparación hasta el cierre. No hace falta llegar con todas las respuestas. Nuestra propuesta es crear un espacio donde las personas puedan compartir lo que saben, escuchar otras experiencias y decidir un próximo paso que tenga sentido para ellas.

Pensemos en tres momentos: antes del encuentro, durante la conversación y al terminar. En cada uno, revisaremos qué preparar, qué observar y qué dejar acordado.

**Notas de exposición:** mirar al grupo y hacer una pausa breve después de los tres momentos. Presentar estas pautas como una propuesta adaptable al contexto.

## Antes: preparar el encuentro

**Texto hablado**

Antes de convocar, escriban el propósito en una frase. Por ejemplo: reunir ideas para mejorar un espacio del barrio y elegir una acción que podamos comenzar. Si esa frase incluye demasiadas tareas, acótenla. El taller necesita una pregunta que las personas puedan trabajar en el tiempo disponible.

Después, revisen quiénes deberían participar y cómo recibirán la invitación. Expliquen para qué es el encuentro, dónde será, cuánto durará y si deben llevar algo. Consulten qué condiciones de acceso necesitan considerar, como el idioma, el traslado o la disposición del lugar.

Preparen materiales sencillos y distribuyan responsabilidades: quién facilita, quién registra y quién cuida el tiempo. Acuerden cómo conservarán las ideas sin atribuir comentarios a una persona cuando no sea necesario. Lleguen con una secuencia breve y un margen para adaptarla. El plan debe ayudarnos a conducir, sin obligarnos a ignorar lo que suceda.

**Notas de exposición:** enfatizar «una frase» y «una pregunta». No abrir todavía una conversación larga; se está ofreciendo una guía de cinco minutos.

## Durante: facilitar y escuchar

**Texto hablado**

Al comenzar, den la bienvenida y expliquen el propósito, el tiempo disponible y el recorrido. Propongan acuerdos claros: escuchar sin interrumpir, hablar desde la propia experiencia y poder pasar el turno. Pregunten si falta algún acuerdo antes de continuar.

Planteen una pregunta por vez. Pueden dar un momento para pensar individualmente, luego conversar en grupos pequeños y finalmente compartir con el conjunto. Adapten esta propuesta al número de participantes y a las formas de participación que el grupo prefiera.

Mientras conversan, busquen que haya distintas voces. Inviten a participar sin presionar a quien prefiere escuchar. Si alguien ocupa mucho tiempo, agradezcan su aporte y abran la palabra a otras personas. Si aparece un desacuerdo, separen las posiciones de las personas: ¿qué necesidad intenta atender cada idea? No hace falta resolver todas las diferencias en ese momento.

Registren las ideas con palabras que el grupo reconozca. Antes de agruparlas o resumirlas, comprueben: «¿Esto representa lo que quisieron decir?». Avisen cuando se acerque el cierre. Si surge un tema que no podrán abordar, anótenlo como pendiente y acuerden cómo retomarlo, sin prometer una respuesta que todavía no tienen.

**Notas de exposición:** hacer una pausa antes de la pregunta de comprobación y decirla con tono de invitación. Evitar representar conflictos con nombres o experiencias atribuidas al grupo.

## Al terminar: cerrar con claridad

**Texto hablado**

Para cerrar, recuperen la pregunta inicial y lean lo que quedó registrado. Distingan entre ideas, acuerdos y asuntos pendientes. Si van a elegir una acción, expliquen cómo tomarán esa decisión y comprueben que el grupo entiende el procedimiento.

Concreten el próximo paso: qué se hará, quién acepta hacerse cargo y cuándo revisarán el avance. Verifiquen ese compromiso con la persona; anotarlo no significa que ya lo haya aceptado. Si todavía no hay responsables, déjenlo como pendiente.

Pregunten qué se lleva cada participante y qué convendría ajustar para otro encuentro. Agradezcan el tiempo y expliquen por qué medio compartirán el registro. Después, revisen entre voluntarios qué funcionó, qué quedó abierto y qué necesitan preparar para continuar.

**Notas de exposición:** reducir ligeramente el ritmo al enumerar el próximo paso. No convertir la pregunta final en una actividad durante esta exposición breve.

## Despedida

**Texto hablado**

Preparar es aclarar el propósito y las condiciones. Facilitar es escuchar y ayudar a trabajar la pregunta. Cerrar es dejar un registro comprensible y un próximo paso aceptado. Con esa secuencia, ya tienen una base para preparar su primer encuentro.

**Notas de exposición:** cerrar con una pausa breve. Si se abre un turno de preguntas, su duración será adicional a los cinco minutos.

## Duración estimada y uso

El texto hablado contiene 565 palabras. A 120 palabras por minuto y con 17,5 segundos de pausas, la duración estimada es 5:00. Un ritmo de 110–130 palabras por minuto produciría aproximadamente 4:38–5:26 con las mismas pausas. Las notas y los títulos no se leen en voz alta. No se realizó un ensayo cronometrado.

Distribución orientativa: apertura 0:44; preparación 1:15; realización 1:38; cierre 1:01; despedida 0:22. Ajustar las pausas tras ensayar con la persona expositora. No incluye preguntas del público.
