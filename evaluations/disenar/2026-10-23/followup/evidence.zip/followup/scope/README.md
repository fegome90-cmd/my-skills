# Encargos de frontera y auditoría

Los tres prompts están registrados por separado. No se cambió la skill ni producción; no se publicó, instaló o hizo commit. Son pruebas de desarrollo en filesystem compartido, con inputs preparados por el worker; no constituyen evaluación ciega ni comparación de valor.

| Encargo | Resultado | Evidencia y límite |
|---|---|---|
| Solo guion de cinco minutos, sin diapositivas | `script/guion.md` | 565 palabras; 120 ppm + 17,5 segundos de pausas = 5:00 estimados. Notas separadas. Ensayo cronometrado `NOT_RUN`. |
| SQL con duplicados por JOIN 1:N | `sql/after.sql` | `sql/results.json`: seis casos reales `PASS` en SQLite; before, datos, esperado y diff conservados. |
| Auditoría del SKILL.md y sus referencias | `audit/manual-review.md` y `audit/report.json` | Inspector `OK`, 0 findings; seis casos de contraste `PASS`; fuente original intacta. Gate `INCOMPLETE` por cotejo externo de procedencia/derechos no ejecutado; host `NOT_RUN`. |

La salida del guion mantiene el alcance exclusivamente textual; la salida del SQL resuelve el problema técnico sin material visual. La auditoría usa skills-manager en modo review. El candidato `disenar` se utiliza para la modificación visual del deck en `../slides`; estas distinciones escritas no prueban activación automática del host.

`script/input-manifest.json` y `sql/input-manifest.json` congelan los respectivos inputs antes de escribir las soluciones. El input de guion contiene una errata de ruta en su nota de enrutamiento: menciona `referencias/presentaciones.md`; la ruta real consultada es `references/presentaciones.md`. Se mantiene el input congelado y se aclara aquí. `audit/source-manifest.json` fija los 12 archivos del candidato y su revisión. Los checks se resumen en archivos JSON y los stdout/stderr del inspector y del helper se conservan en `audit/commands.json`.

Comandos principales realmente ejecutados:

```bash
node /workspace/scratch/d17c3d8f8225/design-testing/evaluations/disenar/2026-10-23/followup/slides/evidence/test-state.cjs
python3 /workspace/scratch/d17c3d8f8225/design-testing/evaluations/disenar/2026-10-23/followup/scope/sql/run.py
python3 /workspace/scratch/d17c3d8f8225/design-testing/evaluations/disenar/2026-10-23/followup/scope/audit/run.py
python3 /workspace/scratch/d17c3d8f8225/design-testing/evaluations/disenar/2026-10-23/followup/scope/audit/helpers/evidence_gate.py /workspace/scratch/d17c3d8f8225/design-testing/evaluations/disenar/2026-10-23/followup/scope/audit/case.json /workspace/scratch/d17c3d8f8225/design-testing/evaluations/disenar/2026-10-23/followup/scope/audit/report.json
```

La fuente de instrucciones de skills-manager es `skill://plugins_6abcfce948fc8191bcdfb14eb78cbb01/manage-skills/SKILL.md`, leída con sus referencias de calidad y evidencia. Los helpers exactos y su procedencia/hash están en `audit/helpers/` y `audit/helper-provenance.json`. La documentación primaria técnica usada para el SQL, el movimiento reducido y el contraste se lista en `sources.json`. Los repositorios o ZIP citados por el candidato no se suponen accesibles ni verificados por estar enlazados.
