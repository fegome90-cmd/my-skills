# Auditoría del candidato `disenar`

Estado del encargo: auditoría local completada, sin cambios ni instalación. El paquete puede continuar a validación dirigida. No hay evidencia suficiente para declararlo globalmente listo o disponible en el host.

Objeto: los 12 archivos de `source/disenar`, copia exacta de la ruta suministrada. Revisión SHA-256 del inventario completo: `43408fe0c1b256ed91703b8c5139e568e6c6130a2bfe37629ff67be475000385`. Se conserva cada hash en `source-manifest.json`; `source-unchanged.json` prueba igualdad entre fuente original, copia y manifiesto tras las ejecuciones. No se leyó ninguna rúbrica ni la salida de otros workers.

Modo de skills-manager: `review`. Se leyeron su raíz y las referencias `quality.md` y `evidence.md`; se conservaron las tres utilidades sin modificaciones en `helpers`. Se ejecutó `candidate_lint.py`. `installation_gate.py` solo fue cargado por el import del inspector; no se ejecutó una instalación ni su preflight. El helper `evidence_gate.py` resume esta evidencia y no juzga su verdad semántica.

## Hallazgos y límites

1. **No se confirmó un defecto bloqueante de estructura local.** El inspector devuelve `OK`, 0 findings, raíz de 6.718 bytes y 64 líneas. Confirma YAML, identidad y enlaces Markdown bajo su cobertura declarada. Los nueve documentos de referencias existen y se leyeron. El ejemplo del helper de contraste usa una ruta relativa a la skill, y el archivo existe. `agents/openai.yaml` contiene nombre visible, descripción y prompt coherentes con `disenar`. Su lectura y parseo no prueban que el host lo acepte.
2. **La preparación de todos los medios sigue sin demostrarse.** Se ejecutó el helper de contraste, y este worker produjo un deck local y dos salidas de frontera. No se probó producción de iconos, identidades, impresos, PDF, PPTX u otros formatos. La skill declara correctamente que aporta procedimiento y no incluye exportadores. Es un límite de evidencia, no una dependencia rota. No se infiere utilidad comparativa frente a instrucciones ordinarias.
3. **La procedencia está documentada; su verificación externa no está cerrada.** `references/fuentes.md` identifica fuentes y revisiones, declara síntesis e implementación propias, separa assets de los permisos del repositorio y señala que no se incorporan ejecutables ni archivos de colecciones externas. El inspector conserva 40 ocurrencias de enlaces externos sin verificar. Esas URLs son referencias informativas, no imports operativos obligatorios. No se comparó la síntesis con todos los originales ni se verificaron permisos de cada repositorio privado o del ZIP mencionado. No se inventa una licencia para el paquete ni se interpreta su ausencia como un fallo universal. Si se pretende distribuir material copiado o atribuir derechos externos, ese punto requiere comprobación específica.
4. **La integración y la activación automática no fueron probadas.** La descripción excluye backend, auditorías de instrucciones y guiones que excluyen diseño visual. Es coherente con los cuatro encargos de este fixture. La ruta escrita y las salidas locales son observaciones de desarrollo; no prueban descubrimiento, activación, instalación, precedencia o readback del host. Esas comprobaciones quedan `NOT_RUN`.

## Evidencia ejecutada

| Comprobación | Método y resultado | Cobertura |
|---|---|---|
| Estructura y enlaces internos | `candidate_lint.py`: `OK`, 0 findings | Lint local; excluye anchors, host, comportamiento, URLs externas y sintaxis Markdown no soportada |
| Estabilidad de fuente | Inventario y SHA-256 antes/después: `PASS` | Los 12 archivos exactos; no se modificó producción |
| Helper de contraste | Seis casos `PASS` | Negro/blanco = 21; blanco/blanco = 1; gris `#777` sobre blanco = 4,478... y `FAIL` al umbral 4,5; alpha, NaN y umbral 22 rechazados |
| Límites de autoridad | Lectura de raíz y referencias: `PASS` | Respeta contrato, auditoría sin editar, publicación solo autorizada, fuentes como datos |
| Enrutamiento de alcance | Decisión manual y artefactos de los cuatro encargos: `PASS` de desarrollo | No equivale a activación automática |
| Fuentes externas/derechos | `NOT_RUN` en cuanto a cotejo completo | Documentación local revisada; no se acreditan permisos ajenos |
| Render e interacción real del deck | `NOT_RUN` por este worker | A cargo del coordinador; el doble de DOM no los sustituye |
| Host/instalación | `NOT_RUN` | No se solicitó instalar |

No se emite `TECHNICALLY_VALID`: la suite queda incompleta por la verificación externa de procedencia/derechos registrada como pendiente. Este resultado no exige modificar el candidato ni instalarlo. Las declaraciones normativas consultadas en W3C y la semántica de CSSWG apoyan únicamente los puntos técnicos usados; no revalidan el paquete entero.

Fuentes primarias consultadas el 23-10-2026: [W3C, contraste mínimo](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html), [CSSWG, preferencia de movimiento reducido](https://drafts.csswg.org/mediaqueries-5/#prefers-reduced-motion). La segunda es un borrador de trabajo. Los comandos y stdout/stderr reales se conservan en `commands.json`; `helper-results.json` no convierte el cálculo entre dos colores en accesibilidad global.

Condiciones: prueba de desarrollo en el mismo contexto y filesystem compartido, no ciega; modelo exacto no expuesto al worker; sin usuarios reales, publicación, commits, instalación de dependencias ni cambios al candidato.
