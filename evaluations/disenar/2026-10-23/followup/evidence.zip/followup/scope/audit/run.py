"""Read-only source review evidence; writes results outside the candidate."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys

ROOT=Path(__file__).parent
CANDIDATE=ROOT/'source/disenar'
commands=[]
manifest=json.loads((ROOT/'source-manifest.json').read_text())
parser=argparse.ArgumentParser(description='Compare the frozen snapshot with a real candidate checkout; never silently substitute the snapshot for its source.')
parser.add_argument('--candidate',type=Path,help='Real candidate checkout to compare with the frozen inventory. Defaults to the historical source if it still exists.')
args=parser.parse_args()
historical=Path(manifest['source'])
checked_candidate=args.candidate if args.candidate is not None else historical
selection='explicit --candidate' if args.candidate is not None else 'historical source default'
if not checked_candidate.is_dir():
    parser.error(f'Candidate source is missing or inaccessible: {checked_candidate}. Use --candidate PATH to select a real checkout. The frozen snapshot will not be used as its source.')
if checked_candidate.resolve()==CANDIDATE.resolve():
    parser.error('The candidate is the evidence snapshot, not a real source checkout. Use --candidate PATH to select the real checkout to verify.')

def inventory(directory):
    return {p.relative_to(directory).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(directory.rglob('*')) if p.is_file()}

# Validate both byte sets before writing new execution evidence.
actual=inventory(CANDIDATE)
current=inventory(checked_candidate)
if actual!=manifest['files']:
    parser.error('Frozen snapshot differs from source-manifest.json; review the evidence revision before running.')
if current!=manifest['files']:
    parser.error(f'Candidate checkout differs from the frozen inventory: {checked_candidate}. Select the matching checkout with --candidate PATH or create a new evidence revision.')

def execute(args):
    result=subprocess.run(args,text=True,capture_output=True)
    record={'command':args,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
    commands.append(record)
    return record

lint=execute([sys.executable,str(ROOT/'helpers/candidate_lint.py'),str(CANDIDATE)])
(ROOT/'candidate-lint.json').write_text(lint['stdout'])
parsed=json.loads(lint['stdout'])
assert lint['exit_code']==0 and parsed['status']=='OK'
assert parsed['candidate_revision']=='43408fe0c1b256ed91703b8c5139e568e6c6130a2bfe37629ff67be475000385'
contrast=[]
for label,args,expected_code,expected_status in [
    ('maximum',['#000','#fff','--threshold','21'],0,'PASS'),
    ('same-color',['#fff','#fff'],1,'FAIL'),
    ('near-threshold-no-rounding',['#777','#fff','--threshold','4.5'],1,'FAIL'),
    ('alpha-rejected',['#0008','#fff'],2,None),
    ('nan-rejected',['#000','#fff','--threshold','nan'],2,None),
    ('out-of-range-threshold',['#000','#fff','--threshold','22'],2,None),
]:
    record=execute([sys.executable,str(CANDIDATE/'scripts/contrast.py'),*args])
    assert record['exit_code']==expected_code,(label,record)
    if expected_status:
        output=json.loads(record['stdout']);assert output['status']==expected_status
        if label=='maximum':assert output['ratio']==21
        if label=='same-color':assert output['ratio']==1
        if label=='near-threshold-no-rounding':assert 4.47 < output['ratio'] < 4.5
    contrast.append({'id':label,'status':'PASS',**record})
(ROOT/'helper-results.json').write_text(json.dumps({'checks':contrast,'scope':'Executed contrast helper only; no overall accessibility validation.'},ensure_ascii=False,indent=2)+'\n')
assert inventory(CANDIDATE)==manifest['files']==inventory(checked_candidate)
(ROOT/'source-unchanged.json').write_text(json.dumps({'status':'PASS','snapshot_matches_frozen_manifest':True,'checked_candidate_matches_frozen_manifest':True,'checked_candidate':str(checked_candidate.resolve()),'candidate_selection':selection,'historical_source':str(historical),'historical_source_checked':checked_candidate.resolve()==historical.resolve(),'revision':manifest['revision'],'files_count':len(actual)},indent=2)+'\n')
(ROOT/'commands.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'lint':parsed['status'],'lint_findings':len(parsed['findings']),'lint_unverified_external':len(parsed['unverified']),'helper_cases':len(contrast),'source_unchanged':True},ensure_ascii=False))
