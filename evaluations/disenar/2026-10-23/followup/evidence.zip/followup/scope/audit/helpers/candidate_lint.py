#!/usr/bin/env python3
"""Read-only, local-scope skill inspector. It never approves behavior or installation.

Python 3.9+. PyYAML is required for frontmatter checks, never auto-installed.
Markdown support is deliberately bounded; see the JSON coverage and unverified fields.
"""
import hashlib
import html
import json
import os
from pathlib import Path
import re
import sys
from typing import List, Optional
from urllib.parse import unquote, urlsplit

# Resolve only the manager's trusted helper directory, never a candidate's scripts.
sys.dont_write_bytecode = True
_HELPERS = str(Path(__file__).resolve().parent)
if _HELPERS not in sys.path:
    sys.path.insert(0, _HELPERS)
from installation_gate import inventory, fingerprint


def _result():
    return {
        'schema_version': 1, 'status': 'BLOCKED', 'candidate_revision': None,
        'files': {}, 'metrics': {}, 'findings': [], 'unverified': [],
        'coverage': {
            'yaml': 'SafeLoader with duplicate-key rejection; installed PyYAML required',
            'identity': 'Skills Manager ASCII profile; name matches candidate directory',
            'markdown': 'Conventional single-line inline links/images and reference definitions/full/collapsed/defined-shortcut links in all *.md files',
            'excluded': ['fenced code', 'inline code', 'HTML comments', 'frontmatter'],
            'not_fully_parsed': ['CommonMark', 'nested labels', 'multiline links', 'indented code', 'HTML links', 'vault wikilinks', 'undefined shortcut references', 'footnote labels (their bodies are scanned)'],
            'anchors': False, 'behavior': False, 'host': False, 'external_urls': False,
            'candidate_code_execution': False,
        },
    }


def _finding(result, code, severity, file, line, message):
    item = dict(code=code, severity=severity, file=file, line=line, message=message)
    if item not in result['findings']:
        result['findings'].append(item)


def _pending(result, check, file, line, reason, blocking):
    item = dict(check=check, file=file, line=line, reason=reason, blocking=blocking)
    if item not in result['unverified']:
        result['unverified'].append(item)


def _finish(result):
    if any(x['severity'] == 'ERROR' for x in result['findings']):
        result['status'] = 'ERROR'
    elif any(x['blocking'] for x in result['unverified']):
        result['status'] = 'BLOCKED'
    else:
        result['status'] = 'OK'
    result['findings'].sort(key=lambda x: (x['file'] or '', x['line'] or 0, x['code'], x['message']))
    result['unverified'].sort(key=lambda x: (x['file'] or '', x['line'] or 0, x['check'], x['reason']))
    return result


def _blank(text):
    """Mask text while preserving offsets and line numbers."""
    return ''.join('\n' if ch == '\n' else ' ' for ch in text)


def _frontmatter(text, root, result):
    lines = text.splitlines(keepends=True)
    if not lines or lines[0].rstrip('\r\n') != '---':
        _finding(result, 'FRONTMATTER_MISSING', 'ERROR', 'SKILL.md', 1, 'Start SKILL.md with YAML frontmatter delimited by --- lines.')
        return text
    end = next((i for i in range(1, len(lines)) if lines[i].rstrip('\r\n') == '---'), None)
    if end is None:
        _finding(result, 'FRONTMATTER_UNCLOSED', 'ERROR', 'SKILL.md', 1, 'Close the YAML frontmatter with a --- line.')
        return _blank(text)
    header = ''.join(lines[1:end])
    masked = _blank(''.join(lines[:end + 1])) + ''.join(lines[end + 1:])
    try:
        import yaml
    except ImportError:
        _finding(result, 'YAML_PARSER_UNAVAILABLE', 'WARNING', 'SKILL.md', 1, 'PyYAML is not available. Provide an approved environment with PyYAML; no install or fallback was attempted.')
        _pending(result, 'frontmatter', 'SKILL.md', 1, 'PyYAML unavailable; YAML was not validated.', True)
        return masked
    result['coverage']['yaml_version'] = yaml.__version__

    class UniqueLoader(yaml.SafeLoader):
        def construct_mapping(self, node, deep=False):
            seen = set()
            for key, _ in node.value:
                if key.tag == 'tag:yaml.org,2002:merge':
                    raise yaml.constructor.ConstructorError(None, None, 'Merge keys are unsupported by this inspector; use explicit fields.', key.start_mark)
                value = self.construct_object(key, deep=deep)
                try:
                    if value in seen:
                        raise yaml.constructor.ConstructorError(None, None, 'Duplicate mapping key: ' + repr(value), key.start_mark)
                    seen.add(value)
                except TypeError:
                    raise yaml.constructor.ConstructorError(None, None, 'Mapping keys must be scalar and hashable.', key.start_mark)
            return super().construct_mapping(node, deep=deep)

    try:
        data = yaml.load(header, Loader=UniqueLoader)
        if not isinstance(data, dict):
            _finding(result, 'YAML_MAPPING_REQUIRED', 'ERROR', 'SKILL.md', 2, 'Frontmatter must be a mapping with textual name and description fields.')
            return masked
    except (yaml.YAMLError, RecursionError, ValueError) as exc:
        mark = getattr(exc, 'problem_mark', None)
        code = 'YAML_DUPLICATE_KEY' if 'Duplicate mapping key:' in str(exc) else 'YAML_INVALID'
        _finding(result, code, 'ERROR', 'SKILL.md', mark.line + 2 if mark else 2, str(exc))
        return masked
    for field in ('name', 'description'):
        value = data.get(field)
        line = next((i + 2 for i, ln in enumerate(header.splitlines()) if re.match(r'\s*[\"\']?' + field + r'[\"\']?\s*:', ln)), 2)
        if not isinstance(value, str) or not value.strip():
            _finding(result, 'REQUIRED_FIELD_INVALID', 'ERROR', 'SKILL.md', line, field + ' must be a nonempty string.')
    name = data.get('name')
    if isinstance(name, str) and name.strip():
        if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*', name) or len(name) > 64:
            _finding(result, 'NAME_PROFILE', 'ERROR', 'SKILL.md', 2, 'This manager uses an ASCII lowercase/digit/single-hyphen name profile, 1–64 characters. Another host may support a different profile; this is not a universal invalidity judgment.')
        if name != root.name:
            _finding(result, 'NAME_FOLDER_MISMATCH', 'ERROR', 'SKILL.md', 2, 'Name must match the candidate directory: ' + root.name)
    description = data.get('description')
    if isinstance(description, str) and len(description) > 1024:
        _finding(result, 'DESCRIPTION_LENGTH', 'ERROR', 'SKILL.md', 2, 'Description exceeds the inspected 1024-character profile.')
    return masked


def _is_escaped(text, pos):
    """An odd run of backslashes escapes punctuation; an even run does not."""
    start = pos
    while start and text[start - 1] == '\\':
        start -= 1
    return (pos - start) % 2 == 1


def _inline_limit(text, start):
    """Do not let inline constructs consume a different paragraph/block."""
    boundary = re.search(
        r'\n[ \t\r]*\n|\n {0,3}(?:'
        r'#{1,6}[ \t]|`{3}|~{3}|>|[-+*][ \t]|[0-9]+[.)][ \t]|<!--|'
        r'[=-]+[ \t]*(?:\r?\n|$)|'
        r'(?:(?:\*[ \t]*){3,}|(?:_[ \t]*){3,}|(?:-[ \t]*){3,})(?:\r?\n|$))',
        text[start:])
    return start + boundary.start() if boundary else len(text)


def _mask_code(text, unparsed=None):
    """Mask supported code/comment contexts in encounter order, preserving offsets.

    A comment marker inside code is literal. Likewise, backticks inside a real
    comment cannot start a code span outside it. Inline spans cannot cross a
    paragraph or an obvious block boundary. This is not a full Markdown parser.
    """
    out, pos, length = [], 0, len(text)
    while pos < length:
        if pos == 0 or text[pos - 1] == '\n':
            line_end = text.find('\n', pos)
            line_end = length if line_end < 0 else line_end + 1
            line = text[pos:line_end]
            if re.match(r'^(?: {4}|\t)', line):
                # Indented code/list continuations are outside this small scanner.
                # Do not let their literal delimiters affect surrounding prose.
                if unparsed is not None and re.search(r'[\[<`]', line):
                    unparsed.append(pos)
                out.append(_blank(line))
                pos = line_end
                continue
            fence = re.match(r'^ {0,3}(`{3,}|~{3,})([^\n]*)', line)
            # Backtick info strings cannot contain backticks.
            if fence and not (fence[1][0] == '`' and '`' in fence[2]):
                end = line_end
                closer = re.compile(r'^ {0,3}' + re.escape(fence[1][0]) +
                                    '{' + str(len(fence[1])) + r',}[ \t]*\r?$')
                while end < length:
                    next_end = text.find('\n', end)
                    next_end = length if next_end < 0 else next_end + 1
                    closing = bool(closer.fullmatch(text[end:next_end].rstrip('\n')))
                    end = next_end
                    if closing:
                        break
                out.append(_blank(text[pos:end]))
                pos = end
                continue
            if re.match(r'^ {0,3}<!--', line):
                end = text.find('-->', pos)
                # A block comment includes the rest of its terminating line.
                end = length if end < 0 else text.find('\n', end + 3)
                end = length if end < 0 else min(end + 1, length)
                out.append(_blank(text[pos:end]))
                pos = end
                continue
        if text[pos] == '\\' and pos + 1 < length:
            out.append(text[pos:pos + 2])
            pos += 2
            continue
        if text.startswith('<!--', pos):
            end = text.find('-->', pos + 4, _inline_limit(text, pos + 4))
            if end >= 0:
                end += 3
                out.append(_blank(text[pos:end]))
                pos = end
                continue
        if text[pos] == '`':
            run_end = pos + 1
            while run_end < length and text[run_end] == '`':
                run_end += 1
            limit = _inline_limit(text, run_end)
            closer = re.search(r'(?<!`)' + '`' * (run_end - pos) + r'(?!`)',
                               text[run_end:limit])
            if closer:
                end = run_end + closer.end()
                out.append(_blank(text[pos:end]))
                pos = end
                continue
            out.append(text[pos:run_end])
            pos = run_end
            continue
        out.append(text[pos])
        pos += 1
    return ''.join(out)


def _destination(raw):
    """Return a destination for the conventional syntax, otherwise None."""
    if not raw.strip():
        return ''
    match = re.fullmatch(r'\s*(?:<([^>\n]*)>|((?:\\.|[^\s])+?))(?:\s+(?:"[^"\n]*"|\'[^\'\n]*\'|\([^\n]*\)))?\s*', raw)
    if not match:
        return None
    target = match[1] if match[1] is not None else match[2]
    # Decode once, in source order: an escaped ampersand must not start an entity.
    return re.sub(
        r"\\([!\"#$%&'()*+,\-./:;<=>?@\[\\\]^_`{|}~])|&(?:#[xX][0-9a-fA-F]{1,6}|#[0-9]{1,7}|[A-Za-z][A-Za-z0-9]{1,31});",
        lambda m: (m[1] if m[1] is not None else
                   html.unescape(m[0]) if m[0].startswith('&#') or m[0][1:] in html.entities.html5
                   else m[0]), target)


def _scan_markdown(text, source, root, result, referenced):
    unparsed = []
    masked = _mask_code(text, unparsed)
    for pos in unparsed:
        _pending(result, 'indented_markdown', source, text.count('\n', 0, pos) + 1,
                 'Indented resource/code syntax needs manual review; not claimed as a missing file.', True)

    def line_at(pos):
        return masked.count('\n', 0, pos) + 1

    def check_target(raw, pos):
        line = line_at(pos)
        target = _destination(raw)
        if target is None:
            _finding(result, 'LINK_SYNTAX_UNSUPPORTED', 'WARNING', source, line, 'Review this link manually; destination syntax is outside the conventional single-line profile.')
            _pending(result, 'local_link_syntax', source, line, raw, True)
            return
        # Absolute/URI dependencies are reported without opening or resolving them.
        if target.startswith(('/', '~/', '\\')) or re.match(r'^[A-Za-z]:[/\\]', target):
            external(target, line)
            return
        try:
            parts = urlsplit(target)
        except ValueError:
            _pending(result, 'link_uri_syntax', source, line, 'Unrecognized URI: ' + target, True)
            return
        if parts.scheme or parts.netloc:
            _pending(result, 'external_url', source, line, 'Not fetched: ' + target, False)
            return
        path = unquote(parts.path)
        if not path:
            return  # Same-document anchor; coverage explicitly excludes anchors.
        # abspath normalizes '..' lexically, with no filesystem reads outside root.
        absolute = Path(os.path.abspath(root / Path(source).parent / path))
        if not absolute.is_relative_to(root):
            external(target, line)
            return
        relative = absolute.relative_to(root).as_posix()
        if relative in result['files']:
            referenced.add(relative)
        elif absolute.is_dir():
            _pending(result, 'directory_link', source, line, 'Directory exists; individual required resources still need review: ' + target, False)
        else:
            _finding(result, 'LOCAL_LINK_MISSING', 'ERROR', source, line, 'Bundled destination is missing: ' + target + ' (resolved within candidate to ' + relative + ').')

    def external(target, line):
        _finding(result, 'EXTERNAL_DEPENDENCY', 'WARNING', source, line, 'Outside candidate; not opened and not presumed missing: ' + target)
        _pending(result, 'external_dependency', source, line, target + '; resolve separately if required by the case.', False)

    # Conventional reference definitions, including definitions used by shortcuts.
    definitions = {}
    definition_spans = []
    norm = lambda s: ' '.join(s.split()).casefold()
    for match in re.finditer(r'^ {0,3}\[((?!\^)[^\]\n]+)\]:[ \t]*([^\n]*)$', masked, flags=re.M):
        key = norm(match[1])
        if key in definitions and definitions[key] != match[2]:
            _finding(result, 'REFERENCE_AMBIGUOUS', 'ERROR', source, line_at(match.start()), 'Conflicting definitions for reference: ' + key)
        definitions[key] = match[2]
        check_target(match[2], match.start())
        definition_spans.append(match.span())
    working = list(masked)
    for begin, end in definition_spans:
        working[begin:end] = _blank(masked[begin:end])
    working = ''.join(working)

    for match in re.finditer(r'!?\[((?:\\.|[^\\\]\n])*)\]\[((?:\\.|[^\\\]\n])*)\]', working):
        bracket = match.start() + (1 if match[0].startswith('!') else 0)
        if _is_escaped(working, bracket):
            continue
        key = norm(match[2] or match[1])
        if key not in definitions:
            _finding(result, 'REFERENCE_UNDEFINED', 'ERROR', source, line_at(match.start()), 'Define the explicit reference label: ' + key)

    for match in re.finditer(r'!?\[(?:\\.|[^\\\]\n])*\]\(', working):
        bracket = match.start() + (1 if match[0].startswith('!') else 0)
        if _is_escaped(working, bracket):
            continue
        start, pos, depth = match.end(), match.end(), 1
        angle, quote = False, None
        while pos < len(working) and working[pos] != '\n':
            ch = working[pos]
            if ch == '\\':
                pos += 2
                continue
            if quote:
                if ch == quote:
                    quote = None
            elif angle:
                if ch == '>':
                    angle = False
            elif ch == '<':
                angle = True
            elif ch in ('"', "'") and pos > start and working[pos - 1].isspace():
                quote = ch
            elif ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
                if depth == 0:
                    break
            pos += 1
        if depth:
            _finding(result, 'LINK_SYNTAX_UNSUPPORTED', 'WARNING', source, line_at(match.start()), 'Unclosed or multiline inline link; inspect the resource manually.')
            _pending(result, 'local_link_syntax', source, line_at(match.start()), working[match.start():pos], True)
        else:
            check_target(working[start:pos], match.start())

    for match in re.finditer(r'<(?:a|img)\b[^>]*\b(?:href|src)\s*=\s*["\']([^"\']*)', working, re.I):
        target = match[1]
        line = line_at(match.start())
        outside = bool(re.match(r'^[a-zA-Z][\w+.-]*:', target) or target.startswith(('/', '~/')))
        if not outside:
            local = Path(os.path.abspath(root / Path(source).parent / unquote(target.split('#', 1)[0])))
            outside = not local.is_relative_to(root)
        _finding(result, 'HTML_LINK_UNSUPPORTED', 'WARNING', source, line, 'HTML link was not validated: ' + target)
        _pending(result, 'html_link', source, line, target, not outside)
    for match in re.finditer(r'\[\[([^\]\n]+)\]\]', working):
        _pending(result, 'vault_wikilink', source, line_at(match.start()), 'Host/vault-dependent target, not checked locally: ' + match[1], False)
    for match in re.finditer(r'(?:/Users/|/home/)[A-Za-z0-9_.-]+(?:/[^\s<>]*)?', masked):
        _finding(result, 'PERSONAL_PATH_REVIEW', 'WARNING', source, line_at(match.start()), 'Review portability and personal data in this path; it may be an intentional example: ' + match[0])


def lint_candidate(root: Path) -> dict:
    """Inspect one directory without mutating it or running its code."""
    result = _result()
    try:
        root = Path(root)
        if not root.exists() and not root.is_symlink():
            _pending(result, 'inventory', None, None, 'Candidate directory is not accessible or does not exist.', True)
            return _finish(result)
        # Do not resolve the root symlink away before the inventory rejects it.
        files = inventory(root)
        root = root.resolve()
        result['files'] = dict(sorted(files.items()))
        result['candidate_revision'] = fingerprint(files)
    except ValueError as exc:
        _finding(result, 'CANDIDATE_STRUCTURE', 'ERROR', None, None, str(exc))
        return _finish(result)
    except (OSError, TypeError) as exc:
        _pending(result, 'inventory', None, None, 'Incomplete inventory: ' + str(exc), True)
        return _finish(result)

    referenced = {'SKILL.md'}
    for relative in sorted(files):
        if not relative.lower().endswith('.md'):
            continue
        try:
            data = (root / relative).read_bytes()
            if hashlib.sha256(data).hexdigest() != files[relative]:
                _pending(result, 'stable_candidate', relative, None, 'Bytes changed after inventory; rerun on a stable candidate.', True)
            text = data.decode('utf-8')
        except UnicodeError:
            _finding(result, 'MARKDOWN_ENCODING', 'ERROR', relative, None, 'Markdown must be readable as UTF-8 for this inspector.')
            continue
        except OSError as exc:
            _pending(result, 'markdown_read', relative, None, str(exc), True)
            continue
        if relative == 'SKILL.md':
            result['metrics'] = {'root_bytes': len(data), 'root_lines': len(text.splitlines())}
            if result['metrics']['root_lines'] > 500:
                _finding(result, 'ROOT_SIZE_REVIEW', 'INFO', relative, None, 'More than 500 lines: consider moving conditional detail, without hiding the main procedure. Size alone is not a failure.')
            text = _frontmatter(text, root, result)
        _scan_markdown(text, relative, root, result, referenced)
    for path in sorted(files):
        if path.startswith(('references/', 'assets/')) and path not in referenced:
            _finding(result, 'POSSIBLY_UNREFERENCED', 'INFO', path, None, 'Not found as a conventional Markdown file target; may be used in code or by the host. Review, do not delete automatically.')
    try:
        if inventory(root) != files:
            _pending(result, 'stable_candidate', None, None, 'Inventory changed during inspection; rerun.', True)
            result['candidate_revision'], result['files'] = None, {}
    except (OSError, ValueError) as exc:
        _pending(result, 'stable_candidate', None, None, 'Could not recheck inventory: ' + str(exc), True)
        result['candidate_revision'], result['files'] = None, {}
    return _finish(result)


def main(argv: Optional[List[str]] = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    if len(args) != 1:
        result = _result()
        _pending(result, 'usage', None, None, 'Usage: candidate_lint.py PATH_TO_SKILL_DIRECTORY', True)
        result = _finish(result)
    else:
        result = lint_candidate(Path(args[0]))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return {'OK': 0, 'ERROR': 1, 'BLOCKED': 2}[result['status']]


if __name__ == '__main__':
    sys.exit(main())

