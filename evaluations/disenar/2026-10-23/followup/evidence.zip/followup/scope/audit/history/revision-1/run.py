"""Read-only source review evidence; writes results outside the candidate."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT=Path(__file__).parent
CANDIDATE=ROOT/'source/disenar'
commands=[]

def execute(args):
    result=subprocess.run(args,text=True,capture_output=True)
    record={'command':args,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
    commands.append(record)
    return record

lint=execute([sys.executable,str(ROOT/'helpers/candidate_lint.py'),str(CANDIDATE)])
(ROOT/'candidate-lint.json').write_text(lint['stdout'])
parsed=json.loads(lint['stdout'])
assert lint['exit_code']==0 and parsed['status']=='OK'
assert parsed['candidate_revision']=='43408fe0c1b256ed91703b8c5139e568e6c6130a2bfe37629ff67be475000385'
contrast=[]
for label,args,expected_code,expected_status in [
    ('maximum',['#000','#fff','--threshold','21'],0,'PASS'),
    ('same-color',['#fff','#fff'],1,'FAIL'),
    ('near-threshold-no-rounding',['#777','#fff','--threshold','4.5'],1,'FAIL'),
    ('alpha-rejected',['#0008','#fff'],2,None),
    ('nan-rejected',['#000','#fff','--threshold','nan'],2,None),
    ('out-of-range-threshold',['#000','#fff','--threshold','22'],2,None),
]:
    record=execute([sys.executable,str(CANDIDATE/'scripts/contrast.py'),*args])
    assert record['exit_code']==expected_code,(label,record)
    if expected_status:
        output=json.loads(record['stdout']);assert output['status']==expected_status
        if label=='maximum':assert output['ratio']==21
        if label=='same-color':assert output['ratio']==1
        if label=='near-threshold-no-rounding':assert 4.47 < output['ratio'] < 4.5
    contrast.append({'id':label,'status':'PASS',**record})
(ROOT/'helper-results.json').write_text(json.dumps({'checks':contrast,'scope':'Executed contrast helper only; no overall accessibility validation.'},ensure_ascii=False,indent=2)+'\n')
manifest=json.loads((ROOT/'source-manifest.json').read_text())
actual={p.relative_to(CANDIDATE).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(CANDIDATE.rglob('*')) if p.is_file()}
original=Path(manifest['source'])
current={p.relative_to(original).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(original.rglob('*')) if p.is_file()}
assert actual==manifest['files']==current
(ROOT/'source-unchanged.json').write_text(json.dumps({'status':'PASS','snapshot_matches_frozen_manifest':True,'original_matches_frozen_manifest':True,'revision':manifest['revision'],'files_count':len(actual)},indent=2)+'\n')
(ROOT/'commands.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'lint':parsed['status'],'lint_findings':len(parsed['findings']),'lint_unverified_external':len(parsed['unverified']),'helper_cases':len(contrast),'source_unchanged':True},ensure_ascii=False))
