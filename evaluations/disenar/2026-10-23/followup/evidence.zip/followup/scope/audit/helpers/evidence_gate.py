#!/usr/bin/env python3
"""Summarize evaluator records; does not judge semantic correctness."""
import hashlib
import json
from pathlib import Path
import sys

STATUSES = ('PASS', 'FAIL', 'NOT_RUN', 'BLOCKED', 'NOT_APPLICABLE')


def validate(contract, report, evidence_root):
    for record, field in ((contract, 'mandatory_checks'), (report, 'checks'),
                          (report, 'material_conflicts'), (report, 'limits')):
        if not isinstance(record.get(field), list):
            raise ValueError(f'{field} must be a list')
    required_text = ('case_id', 'contract_revision', 'subject_revision', 'evaluator_revision',
                     'date', 'model', 'environment', 'evaluation_integrity')
    for field in required_text:
        if not isinstance(report.get(field), str) or not report[field].strip():
            raise ValueError(f'Missing identity field: {field}')
    if report['evaluation_integrity'].upper() == 'INVALID':
        raise ValueError('Evaluation evidence is invalid')
    if report.get('subject_type') not in ('manager', 'produced_skill'):
        raise ValueError('Invalid subject_type')
    if (report['case_id'] != contract['case_id'] or
            report['contract_revision'] != contract['revision']):
        raise ValueError('Case or contract revision mismatch')
    purpose = contract.get('evaluation_purpose', 'value_evaluation')
    if (purpose not in ('value_evaluation', 'technical_validation') or
            report.get('evaluation_purpose', 'value_evaluation') != purpose):
        raise ValueError('Unknown or mismatched evaluation purpose')
    seen = set()
    for check in report['checks']:
        if check['id'] in seen:
            raise ValueError('Duplicate check identity')
        seen.add(check['id'])
        if check['status'] not in STATUSES:
            raise ValueError('Invalid check status')
        if check.get('layer') not in ('static', 'behavior', 'integration'):
            raise ValueError('Invalid evidence layer')
        if not isinstance(check.get('observation'), str) or not check['observation'].strip():
            raise ValueError('Check requires an observation')
        if check['status'] in ('PASS', 'FAIL') and not check['artifacts']:
            raise ValueError('Observed result requires an artifact')
        if check['status'] == 'NOT_APPLICABLE' and not check.get('domain_reason'):
            raise ValueError('NOT_APPLICABLE requires a domain reason')
        for artifact in check['artifacts']:
            relative = Path(artifact['path'])
            resolved = (evidence_root / relative).resolve()
            if relative.is_absolute() or '..' in relative.parts or not resolved.is_relative_to(evidence_root):
                raise ValueError('Artifact path must remain inside report directory')
            if hashlib.sha256(resolved.read_bytes()).hexdigest() != artifact['sha256']:
                raise ValueError('Artifact digest mismatch')


def evaluate(contract, report, evidence_root):
    try:
        validate(contract, report, evidence_root)
    except (KeyError, TypeError, ValueError, OSError) as error:
        return {'decision': 'INVALID', 'errors': [str(error)]}

    totals = {status: 0 for status in STATUSES}
    for check in report['checks']:
        totals[check['status']] += 1
    required = contract['mandatory_checks']
    by_id = {check['id']: check for check in report['checks']}
    if report['material_conflicts']:
        decision = 'CONSULT'
    elif not required or any(key not in by_id for key in required):
        decision = 'INCOMPLETE'
    elif any(by_id[key]['status'] == 'FAIL' for key in required):
        decision = 'REJECT'
    elif any(by_id[key]['status'] in ('NOT_RUN', 'BLOCKED') for key in required):
        decision = 'INCOMPLETE'
    elif all(by_id[key]['status'] == 'NOT_APPLICABLE' for key in required):
        decision = 'INCOMPLETE'
    elif report['subject_type'] == 'produced_skill':
        behavior = [by_id[key] for key in required if by_id[key]['layer'] == 'behavior']
        if contract.get('evaluation_purpose') == 'technical_validation':
            decision = ('TECHNICALLY_VALID' if behavior and
                        all(by_id[key]['status'] == 'PASS' for key in required) else 'INCOMPLETE')
        elif not behavior or any(check.get('baseline_status') not in ('PASS', 'FAIL') for check in behavior):
            decision = 'INCOMPLETE'
        elif any(check['baseline_status'] == 'FAIL' and check['status'] == 'PASS' for check in behavior):
            decision = 'ACCEPT'
        else:
            decision = 'DO_NOT_CREATE'
    else:
        decision = 'ACCEPT'
    return {'decision': decision, 'totals': totals}


if __name__ == '__main__':
    contract = json.loads(Path(sys.argv[1]).read_text())
    report = json.loads(Path(sys.argv[2]).read_text())
    print(json.dumps(evaluate(contract, report, Path(sys.argv[2]).resolve().parent), indent=2))

