#!/usr/bin/env python3
"""Read-only preflight for a host-guided installation. Never grants authority."""
import hashlib
import json
from pathlib import Path
import re
import sys
from datetime import datetime, timezone

sys.dont_write_bytecode = True
from evidence_gate import evaluate

MAX_OBSERVATION_AGE_SECONDS = 300


def digest(data):
    return hashlib.sha256(data).hexdigest()


def fingerprint(value):
    return digest(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())


def object_record(value):
    if not isinstance(value, dict):
        raise ValueError('Expected an object record')
    return value


def inventory(root):
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise ValueError('Candidate must be a real directory')
    files = {}
    pending = [root]
    while pending:
        # iterdir propagates permission/enumeration errors; rglob may silently omit them.
        for path in sorted(pending.pop().iterdir()):
            if path.is_symlink():
                raise ValueError('Symlinks are not accepted')
            if path.is_file():
                files[path.relative_to(root).as_posix()] = digest(path.read_bytes())
            elif path.is_dir():
                pending.append(path)
            else:
                raise ValueError('Unsupported filesystem entry')
    if 'SKILL.md' not in files:
        raise ValueError('SKILL.md is required')
    return files


def read_artifact(ref, root):
    object_record(ref)
    root = Path(root).resolve()
    relative = Path(ref['path'])
    target = (root / relative).resolve()
    if relative.is_absolute() or '..' in relative.parts or not target.is_relative_to(root):
        raise ValueError('Evidence path must stay within evidence directory')
    data = target.read_bytes()
    if digest(data) != ref['sha256']:
        raise ValueError('Evidence digest mismatch')
    return data


def timestamp(value):
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    if result.tzinfo is None:
        raise ValueError('Timestamp must include timezone')
    return result


def answer(decision, reason, **extra):
    return {'decision': decision, 'reason': reason, 'mutated': False, **extra}


def compare_readback(candidate, root):
    """Compare supported materialized readback bytes, not host installation state."""
    try:
        object_record(candidate)
        actual = inventory(root)
        if actual != candidate['files'] or fingerprint(actual) != candidate['revision']:
            return answer('READBACK_MISMATCH', 'Complete inventory differs')
        return answer('BYTES_MATCH', 'Complete materialized inventory matches; host availability is separate')
    except (KeyError, TypeError, ValueError, AttributeError, OSError) as error:
        return answer('INVALID', str(error))


def preflight(dossier, candidate_root, evidence_root, now=None):
    """Summarize verified records. Operator still verifies real approval and host facts."""
    try:
        object_record(dossier)
        if dossier.get('schema_version') != 1:
            raise ValueError('Unsupported schema_version')
        candidate = object_record(dossier['candidate'])
        if not isinstance(candidate['name'], str) or not re.fullmatch('[a-z0-9]+(?:-[a-z0-9]+)*', candidate['name']):
            raise ValueError('Invalid candidate name')
        object_record(candidate['files'])
        actual = inventory(candidate_root)
        if actual != candidate['files'] or fingerprint(actual) != candidate['revision']:
            return answer('STALE_CANDIDATE', 'Candidate bytes differ from the frozen complete inventory')
        text = (Path(candidate_root) / 'SKILL.md').read_text()
        lines = text.splitlines()
        if not lines or lines[0] != '---' or '---' not in lines[1:]:
            raise ValueError('Canonical YAML frontmatter is required')
        header = lines[1:lines[1:].index('---') + 1]
        keys = {}
        for line in header:
            if not line.strip() or line.lstrip().startswith('#') or line.startswith(' '):
                continue
            match = re.fullmatch(r'([a-z][a-z0-9_-]*):[ \t]*(.*)', line)
            if not match or match[1] in keys:
                raise ValueError('Ambiguous frontmatter; use unique canonical top-level keys')
            keys[match[1]] = match[2]
        name = candidate['name']
        if keys.get('name') not in (name, '"' + name + '"', "'" + name + "'"):
            raise ValueError('Candidate name does not match the unique frontmatter name')
        destination = object_record(dossier['destination'])
        if (destination.get('host') != 'dot' or destination.get('scope') != 'personal' or
                destination.get('operation') != 'install_personal_skill' or
                not isinstance(destination.get('account_ref'), str) or not destination['account_ref'].strip()):
            raise ValueError('Only an identified dot personal destination is supported')
        evaluation = object_record(dossier['evaluation'])
        case = object_record(json.loads(read_artifact(evaluation['case'], evidence_root)))
        report = object_record(json.loads(read_artifact(evaluation['report'], evidence_root)))
        report_root = (Path(evidence_root) / evaluation['report']['path']).resolve().parent
        result = evaluate(case, report, report_root)
        expected_decision = ('TECHNICALLY_VALID' if case.get('evaluation_purpose') == 'technical_validation'
                             else 'ACCEPT')
        if (report.get('subject_type') != 'produced_skill' or report.get('subject_revision') != candidate['revision'] or
                result['decision'] != expected_decision):
            return answer('BLOCKED_EVALUATION', 'Required produced-skill decision for these exact bytes and purpose is missing', evaluation=result)
        if 'approval' not in dossier:
            return answer('AWAITING_APPROVAL', 'Specific installation approval is missing')
        approval = object_record(dossier['approval'])
        state = approval.get('status')
        if state is None or state == 'pending':
            return answer('AWAITING_APPROVAL', 'Specific installation approval is missing or pending')
        if state == 'rejected':
            return answer('REJECTED', 'Installation was rejected')
        if state != 'approved':
            raise ValueError('Unknown approval state')
        envelope = {key: dossier[key] for key in ('candidate', 'destination', 'evaluation')}
        request_sha256 = fingerprint(envelope)
        if approval['request_sha256'] != request_sha256:
            return answer('STALE_APPROVAL', 'Approval is not bound to the current candidate, evidence and destination')
        read_artifact(approval['evidence'], evidence_root)
        host = object_record(dossier['host'])
        attempt = object_record(dossier['attempt'])
        state = attempt['status']
        if state not in ('never', 'failed', 'unknown', 'succeeded'):
            raise ValueError('Unknown installation outcome')
        if host.get('complete') is not True or host.get('destination') != destination:
            return answer('BLOCKED_HOST', 'Complete inspection of the exact destination is required')
        observed = timestamp(host['observed_at'])
        current = timestamp(now) if now else datetime.now(timezone.utc)
        age = (current - observed).total_seconds()
        if not 0 <= age <= MAX_OBSERVATION_AGE_SECONDS:
            return answer('BLOCKED_HOST', 'Host observation is not current; inspect again')
        read_artifact(host['evidence'], evidence_root)
        if state != 'never':
            read_artifact(attempt['evidence'], evidence_root)
            if observed <= timestamp(attempt['at']):
                return answer('BLOCKED_HOST', 'Inspect supported host state after the previous attempt before retrying')
        if not isinstance(host['entries'], list):
            raise ValueError('Host entries must be a list')
        matches = []
        for entry in host['entries']:
            object_record(entry)
            if (not isinstance(entry.get('name'), str) or not entry['name'].strip() or
                    not isinstance(entry.get('revision'), str) or not entry['revision'].strip()):
                raise ValueError('Host entries need name and revision')
            if entry['name'] == candidate['name']:
                matches.append(entry)
        if matches:
            if len(matches) == 1 and matches[0]['revision'] == candidate['revision']:
                return answer('VERIFY_EXISTING', 'Matching candidate exists; verify availability instead of reinstalling')
            return answer('COLLISION', 'Name exists with another or ambiguous revision; do not overwrite')
        if state == 'unknown':
            if not host.get('attempt_resolution'):
                return answer('BLOCKED_HOST', 'Absence alone cannot resolve an uncertain attempt; supported terminal/authoritative retry-safety evidence is required')
            read_artifact(host['attempt_resolution'], evidence_root)
        if state == 'succeeded':
            return answer('BLOCKED_HOST', 'Reported success conflicts with absence; resolve before any new mutation')
        return answer('READY', 'Records pass preflight; this is not authorization or installation', request_sha256=request_sha256)
    except (KeyError, TypeError, ValueError, AttributeError, OSError) as error:
        return answer('INVALID', str(error))


if __name__ == '__main__':
    try:
        dossier_path = Path(sys.argv[1]).resolve()
        dossier = json.loads(dossier_path.read_text())
        print(json.dumps(preflight(dossier, Path(sys.argv[2]), dossier_path.parent), indent=2))
    except (IndexError, ValueError, OSError) as error:
        print(json.dumps(answer('INVALID', str(error))))
        sys.exit(2)

