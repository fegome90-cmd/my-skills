(() => {
  'use strict';
  const slides = [...document.querySelectorAll('.slide')];
  const previous = document.getElementById('previous');
  const next = document.getElementById('next');
  const restart = document.getElementById('restart');
  const position = document.getElementById('position');
  const stages = [...document.querySelectorAll('[data-build="stages"] li')];
  let index = 0;
  let revealed = 0;
  function render() {
    slides.forEach((slide, i) => {
      slide.classList.toggle('is-active', i === index);
      slide.setAttribute('aria-hidden', String(i !== index));
    });
    stages.forEach((stage, i) => {
      const pending = i >= revealed;
      stage.classList.toggle('is-pending', pending);
      stage.setAttribute('aria-hidden', String(pending));
    });
    previous.disabled = index === 0;
    next.disabled = index === slides.length - 1;
    position.textContent = `${index + 1} / ${slides.length}` + (index === 1 ? ` · Etapas: ${revealed} de ${stages.length}` : '');
  }
  function forward() {
    if (index === 1 && revealed < stages.length) revealed += 1;
    else if (index < slides.length - 1) { index += 1; if (index === 1) revealed = 0; }
    render();
  }
  function backward() {
    if (index === 1 && revealed > 0) revealed -= 1;
    else if (index > 0) { index -= 1; if (index === 1) revealed = stages.length; }
    render();
  }
  function reset() { index = 0; revealed = 0; render(); }
  previous.addEventListener('click', backward);
  next.addEventListener('click', forward);
  restart.addEventListener('click', reset);
  document.addEventListener('keydown', (event) => {
    if (event.altKey || event.ctrlKey || event.metaKey || /INPUT|TEXTAREA|SELECT/.test(event.target.tagName) || event.target.isContentEditable) return;
    if (event.key === 'ArrowRight' || event.key === 'PageDown') { event.preventDefault(); forward(); }
    if (event.key === 'ArrowLeft' || event.key === 'PageUp') { event.preventDefault(); backward(); }
    if (event.key === 'Home') { event.preventDefault(); reset(); }
    if (event.key === 'End') { event.preventDefault(); index = slides.length - 1; render(); }
  });
  document.documentElement.classList.add('js');
  render();
})();
