# Modificación del deck

Petición aplicada: «Anima la segunda diapositiva para revelar las tres etapas al avanzar y conserva el resto del deck».

- Antes congelado: `input/index.html`, `input/style.css`, `input/deck.js`; hashes en `case.json`.
- Después: `after/index.html`; CSS y JS locales editables, sin dependencias.
- Salida estática completa: `after/static.html`, autónoma y sin JavaScript. La impresión del deck también muestra las tres láminas y todas las etapas.
- Cambio: `change.diff`.

Al entrar en la segunda lámina, las tres etapas están pendientes. Cada avance revela Preparar, Explorar y Compartir; el avance posterior llega al cierre. Retroceder desde el cierre regresa a las tres etapas visibles. Cada retroceso adicional oculta una etapa, hasta volver a la primera lámina. Inicio o Reiniciar borra el progreso; Fin lleva al cierre. Las flechas y PageUp/PageDown funcionan, además de los botones.

La transición es una aparición breve con desplazamiento de 12 px. El estado se actualiza sin temporizadores; una nueva orden cambia directamente el destino vigente. La preferencia `prefers-reduced-motion:reduce` elimina transición y desplazamiento; una modificación de la preferencia afecta las reglas CSS activas sin cambiar el contenido lógico. Esa conducta está implementada; este worker no la reprodujo en navegador.

Comprobaciones de este worker: `evidence/state-results.json` registra 22 observaciones de estado/eventos en Node con un doble mínimo de DOM; no es evidencia de teclado nativo ni de movimiento renderizado. `evidence/static-results.json` conserva comparaciones exactas de las láminas 1 y 3, del CSS original y la inspección de la salida estática. La inspección visual, el foco real, las transiciones, el cambio de preferencia en vivo y la impresión renderizada quedan `NOT_RUN` aquí, a cargo del coordinador.

Prueba de desarrollo en filesystem compartido, sin contexto ciego ni investigación con usuarios. Contenido y código originales del fixture; no se reutilizaron assets externos. Fuentes de procedimiento: candidato `disenar` y sus referencias de presentaciones, movimiento y verificación. Documentación técnica consultada: [CSS Media Queries 5](https://drafts.csswg.org/mediaqueries-5/#prefers-reduced-motion), borrador de trabajo; se utiliza para semántica de preferencia, no como prueba de compatibilidad real.

Para ejecutar los checks locales: `node evidence/test-state.cjs`. Para ver el resultado, abrir `after/index.html` o servir esta carpeta con un servidor estático local. No se publicó ni se instaló nada.
