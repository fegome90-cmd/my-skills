// State/event checks using a tiny DOM double. This is not a browser or render test.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
class Element {
  constructor() { this.classes = new Set(); this.attributes = {}; this.events = {}; this.textContent = ''; this.disabled = false; }
  classList = { add:(name)=>this.classes.add(name), toggle:(name,yes)=>yes?this.classes.add(name):this.classes.delete(name) };
  setAttribute(name,value) { this.attributes[name]=value; }
  addEventListener(type,handler) { this.events[type]=handler; }
}
const slides = Array.from({length:3},()=>new Element());
const stages = Array.from({length:3},()=>new Element());
const controls = Object.fromEntries(['previous','next','restart','position'].map(name=>[name,new Element()]));
const root = new Element();
const events = {};
const document = {
  querySelectorAll:(q)=> q==='.slide'?slides:stages,
  getElementById:(id)=>controls[id],
  documentElement:root,
  addEventListener:(type,handler)=>events[type]=handler
};
vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../after/deck.js'),'utf8'),{document});
const observations=[];
function snapshot(label) {
  const result={label,slide:slides.findIndex(x=>x.classes.has('is-active'))+1,visibleStages:stages.filter(x=>!x.classes.has('is-pending')).length,position:controls.position.textContent,previousDisabled:controls.previous.disabled,nextDisabled:controls.next.disabled};
  for(const s of stages) assert.equal(s.attributes['aria-hidden'],String(s.classes.has('is-pending')));
  observations.push(result); return result;
}
function check(label,slide,visibleStages) {const s=snapshot(label);assert.equal(s.slide,slide);assert.equal(s.visibleStages,visibleStages);}
function click(id) {if(!controls[id].disabled) controls[id].events.click();}
function key(key,extra={}) {let prevented=false;events.keydown({key,target:{tagName:'BODY'},preventDefault(){prevented=true;},...extra});return prevented;}
check('initial',1,0);
assert.equal(controls.previous.disabled,true);
click('next');check('button-enter-second',2,0);
for(let n=1;n<=3;n++){assert.equal(key('ArrowRight'),true);check('reveal-'+n,2,n);}
click('next');check('exit-after-all-revealed',3,3);assert.equal(controls.next.disabled,true);
click('previous');check('return-from-closing',2,3);
for(let n=2;n>=0;n--){key('ArrowLeft');check('reverse-'+n,2,n);}
key('ArrowLeft');check('return-to-first',1,0);
key('PageDown');key('PageDown');check('page-down-reveal',2,1);
key('PageUp');check('page-up-reverse',2,0);
key('ArrowRight');click('restart');check('restart-button',1,0);
key('ArrowRight');key('ArrowRight');key('Home');check('home-clears-progress',1,0);
key('End');check('end',3,0);
key('ArrowLeft');check('reverse-after-end',2,3);
key('Home');for(let n=0;n<30;n++)key('ArrowRight');check('rapid-input-clamps-end',3,3);
for(let n=0;n<30;n++)key('ArrowLeft');check('rapid-reverse-clamps-start',1,0);
assert.equal(key('ArrowRight',{ctrlKey:true}),false);check('modifier-ignored',1,0);
assert.equal(key('ArrowRight',{target:{tagName:'INPUT'}}),false);check('form-ignored',1,0);
assert.equal(key('ArrowRight',{target:{tagName:'DIV',isContentEditable:true}}),false);check('editable-ignored',1,0);
const result={status:'PASS',method:'Node VM and minimal DOM/event double; no rendering engine, layout, actual keyboard, native focus or CSS animation observed.',node:process.version,observations};
fs.writeFileSync(path.join(__dirname,'state-results.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:'PASS',observations:observations.length,method:result.method}));
