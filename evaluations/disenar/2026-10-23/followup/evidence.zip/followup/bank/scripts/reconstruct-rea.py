"""Create an isolated integration copy from a checkout/snapshot of the pinned upstream source."""
from pathlib import Path
import argparse,hashlib,json,shutil
parser=argparse.ArgumentParser()
parser.add_argument('--source',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
a=parser.parse_args()
bundle=Path(__file__).resolve().parents[1]
meta=json.loads((bundle/'case-1-rea'/'provenance.json').read_text())
if a.output.exists():parser.error('--output must not exist; existing projects are never overwritten')
expected=json.loads((bundle/'case-1-rea'/'checks'/'source-integrity.json').read_text())['files']
for r in expected:
 p=a.source/r['path']
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=r['sha256']:
  parser.error(f'Base does not match pinned source: {r["path"]}')
ignore=shutil.ignore_patterns('.git','node_modules','.next','public/r','registry.json','*.tsbuildinfo','source-tree.json','source-manifest.json','fetched-sources.json','registry-inventory.json')
shutil.copytree(a.source,a.output,ignore=ignore)
for r in meta['delta']:
 source=bundle/'case-1-rea'/'delta'/r['path']
 assert hashlib.sha256(source.read_bytes()).hexdigest()==r['after_sha256']
 target=a.output/r['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
print(json.dumps({'status':'PASS','output':str(a.output),'copied_delta_files':len(meta['delta']),'validated_source_files':len(expected),'revision':meta['revision']}))
