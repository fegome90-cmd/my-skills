#!/usr/bin/env bash
set -euo pipefail
bundle="$(cd "$(dirname "$0")/.." && pwd)"
project="${1:-$bundle/case-2-generic/project}"
node --check "$project/app.js"
node --check "$project/profiles.js"
python3 "$bundle/case-2-generic/checks/check-static.py" "$project"
python3 "$bundle/checks-contrast.py"
