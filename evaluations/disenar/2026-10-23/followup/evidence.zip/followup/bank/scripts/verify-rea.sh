#!/usr/bin/env bash
set -euo pipefail
cd "${1:?Provide isolated ui-kit checkout path}"
make check
npm run registry
./node_modules/.bin/shadcn registry validate
NEXT_TELEMETRY_DISABLED=1 npm run build
