import { PROFILES } from './profiles.js';

const select = document.querySelector('#profile-sample');
const saveButton = document.querySelector('#save-profile');
const status = document.querySelector('#profile-status');
let saved = false;

function optionalText(selector, value) {
  const element = document.querySelector(selector);
  element.textContent = value || '';
  element.hidden = !value;
}

function renderProfile(profile) {
  document.querySelector('#profile-name').textContent = profile.name;
  document.querySelector('#profile-occupation').textContent = profile.occupation;
  document.querySelector('#profile-initials').textContent = profile.name.trim().split(/\s+/u).slice(0, 2).map(part => Array.from(part)[0]).join('');
  optionalText('#profile-location', profile.location);
  optionalText('#profile-biography', profile.biography);
  const skills = document.querySelector('#profile-skills');
  skills.replaceChildren(...(profile.skills || []).map(skill => {
    const item = document.createElement('li');
    item.textContent = skill;
    return item;
  }));
  skills.hidden = !profile.skills?.length;
  const details = document.querySelector('#profile-details');
  details.hidden = !profile.details;
  details.open = false;
  details.querySelector('summary').textContent = `Más sobre ${profile.name}`;
  document.querySelector('#profile-details-text').textContent = profile.details || '';
}

select.addEventListener('change', () => {
  renderProfile(PROFILES[select.value] || PROFILES.complete);
  status.textContent = `Muestra: ${select.selectedOptions[0].textContent}. Perfil sintético. ${saved ? 'Guardado durante esta visita.' : ''}`;
});
saveButton.addEventListener('click', () => {
  saved = !saved;
  saveButton.setAttribute('aria-pressed', String(saved));
  saveButton.textContent = saved ? 'Perfil guardado' : 'Guardar perfil';
  status.textContent = saved ? 'Perfil sintético guardado durante esta visita.' : 'Perfil sintético retirado de guardados.';
});

document.querySelector('#year').textContent = String(new Date().getFullYear());
document.querySelector('#demo-toolbar').hidden = false;
saveButton.hidden = false;
