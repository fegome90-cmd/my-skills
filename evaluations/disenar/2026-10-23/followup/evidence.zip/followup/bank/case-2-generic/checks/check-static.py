from html.parser import HTMLParser
from pathlib import Path
import json,sys

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / 'project'
class Parser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids, self.links, self.resources = [], [], []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs: self.ids.append(attrs['id'])
        if tag == 'a': self.links.append(attrs.get('href', ''))
        if tag == 'script': self.resources.append(attrs.get('src', ''))
        if tag == 'link': self.resources.append(attrs.get('href', ''))

p = Parser()
p.feed((root / 'index.html').read_text())
assert len(p.ids) == len(set(p.ids)), 'duplicate id'
assert all(href[1:] in p.ids for href in p.links if href.startswith('#')), 'missing anchor'
assert all((root / path).is_file() for path in p.resources), 'missing local resource'
assert all(not u.startswith(('http:', 'https:', '//')) for u in p.resources), 'external resource'
assert not (root / 'package.json').exists(), 'unexpected package dependency manifest'
print(json.dumps({'status':'PASS', 'method':'Python HTMLParser + filesystem', 'coverage':['unique ids','fragment link targets','local stylesheet and script exist','no external HTML resource','no package manifest'], 'ids':len(p.ids), 'local_resources':p.resources, 'excluded':['browser parse behavior','rendering','interaction','global accessibility']}, indent=2))
