// Datos completamente sintéticos: no identifican a una persona ni un empleo real.
export const PROFILES = {
  complete: {
    name: 'Camila Moreno', occupation: 'Diseño de producto', location: 'Montevideo, Uruguay',
    biography: 'Diseña productos digitales claros y cercanos. Disfruta conectar las necesidades de las personas con las posibilidades de cada equipo.',
    skills: ['Diseño de interfaces', 'Prototipos', 'Contenido'],
    details: 'En este escenario ficticio, Camila facilita talleres y documenta las decisiones del equipo para que cada entrega sea más fácil de mantener.'
  },
  minimal: { name: 'Camila Moreno', occupation: 'Diseño de producto', skills: [] },
  long: {
    name: 'Camila María Moreno de los Santos — perfil sintético con nombre extenso',
    occupation: 'Diseño, contenido y documentación para equipos de productos digitales',
    biography: 'Ejemplo de contenido extenso para revisar el comportamiento de la tarjeta. Este perfil sintético conserva la información completa y permite que el texto ocupe las líneas necesarias, incluso cuando el espacio disponible se reduce.',
    skills: ['Sistemas de diseño y documentación', 'Investigación', 'Contenido', 'Prototipado', 'Accesibilidad', 'HTML semántico'],
    details: 'Contenido adicional del escenario de prueba. No es una biografía ni un testimonio de una persona real.'
  }
};
