# Entrega local de dos casos de diseño

Los casos permanecen separados. Se aplicó la skill local `disenar`; la entrada y sus supuestos están en `inputs.json`. No se modificó el banco real, la skill ni repositorios remotos. No hubo publicación, despliegue ni commit.

## Caso 1 · Banco REA

Se creó `ReaProfileCard`, una composición nueva con primitivas y tokens REA, con su entrada de catálogo, preview, miniatura inerte y fixture sintético. Como el encargo no especificaba qué componente crear, se eligió una tarjeta de perfil. Queda **candidate**: falta revisión visual, teclado, foco, ampliación, 390/1440 px y temas en navegador.

- `case-1-rea/delta/`: los cinco archivos nuevos o modificados para integrar.
- `case-1-rea/integration.patch`: diff sobre `fegome90-cmd/ui-kit` en `4ae9b6e04afbfa50f5a9196a6a0d35d5458d8ec4`.
- `case-1-rea/provenance.json`: revisión, fuentes, SHA, licencia y alcance de derechos. `LICENSE` conserva la licencia MIT del código de Felipe Gonzalez. No se añadieron assets externos ni se reclama fidelidad al sitio de referencia. El manifiesto y el lockfile de dependencias no cambiaron.
- `case-1-rea/checks/`: evidencia focalizada, incluyendo solo el nuevo ítem generado, no los 109 ítems completos.

### Reconstrucción desde upstream

Los snapshots completos y `node_modules` son intermediarios locales y no forman parte de esta entrega. Desde este directorio, obtén un checkout del commit indicado con el acceso habitual al repositorio:

```bash
git clone https://github.com/fegome90-cmd/ui-kit upstream-rea
git -C upstream-rea checkout --detach 4ae9b6e04afbfa50f5a9196a6a0d35d5458d8ec4
python3 scripts/reconstruct-rea.py --source upstream-rea --output isolated-rea
cd isolated-rea
npm ci --ignore-scripts
cd ..
bash scripts/verify-rea.sh isolated-rea
```

`reconstruct-rea.py` valida los 174 archivos del snapshot de código utilizado, crea una copia nueva y aplica los cinco archivos de `delta/`. Rechaza un destino existente. No escribe en el checkout de origen. También admite una copia local que contenga esos archivos originales; no necesita los snapshots del entorno de evaluación.

### Entrada de demo y controles

Desde la copia integrada, `npm run start -- --hostname 127.0.0.1 -p 4125` después del build; `npm run dev -- --hostname 127.0.0.1 -p 4125` para desarrollar.

- `/demo-perfil`: selector de tema claro/oscuro, acentos azul/naranjo/lima y contenido completo/mínimo/extenso. `Más sobre…` abre detalles nativos. `Ver contacto de ejemplo` navega a una sección local.
- `/componentes/rea-profile-card`: entrada real del banco con preview y código; no duplica `FamilyScope`.
- `/componentes`: miniatura en el catálogo.

No hay envío de mensajes ni guardado remoto. Los controles son una implementación disponible para comprobar; su uso en navegador no se observó en esta evaluación.

## Caso 2 · HTML/CSS/JS sin banco

`case-2-generic/project/` contiene la tarjeta autónoma. No se entregó un repositorio genérico concreto; se preparó y conservó un fixture inicial pequeño en `snapshot-initial/`. La tarjeta mantiene sus tokens, encabezado y herramientas HTML/CSS/JS. No requiere paquetes, banco ni red externa.

Camila Moreno y su biografía son **completamente sintéticos**. El selector permite revisar contenido completo, mínimo y extenso; `Guardar perfil` alterna un estado en memoria durante la visita, `Más sobre…` usa `details/summary`, y el contacto es una sección local de ejemplo. La entrega no incluye backend, persistencia entre recargas ni contacto de una persona real. Sin JavaScript sigue disponible el perfil inicial y los detalles nativos.

```bash
bash scripts/verify-generic.sh
python3 -m http.server 4126 --bind 127.0.0.1 --directory case-2-generic/project
```

Entrada: `http://localhost:4126/`. El directorio también contiene `integration.patch`, procedencia y hashes del antes/después.

## Evidencia y límites

| Comprobación | Estado | Cobertura observada |
|---|---|---|
| Integridad del origen | PASS | 174 archivos coinciden con sus Git blob SHA y SHA-256 del commit fijado |
| Reconstrucción aislada | PASS | 174 preimages comprobados; cinco archivos de delta aplicados; sin modificar origen |
| `make check` REA | PASS | Biome, TypeScript y 19 suites/260 pruebas existentes, incluido render de preview y miniatura en jsdom |
| `npm run build` REA | PASS | Compilación de producción y generación estática de 102 páginas; no navegación ni inspección visual |
| Registry | PASS | Generación y validación shadcn de 109 ítems; el nuevo ítem declara `candidate` / `source-code` y dependencias internas reales |
| Contraste calculado | PASS | 12 pares REA y 9 pares genéricos; colores sRGB opacos o borde compuesto sobre fondo. No accesibilidad global |
| Genérico | PASS | Sintaxis de los dos módulos JS; IDs únicos, destinos de fragmentos y recursos locales por HTMLParser/archivos |
| Navegador | BLOCKED | Coordinador observó rechazo de localhost y de URL data por política; el worker no controló navegador |
| Interacción, foco, responsive, zoom | BLOCKED | Requieren navegador; no se atribuyen al render jsdom ni a la compilación |
| E2E / dispositivos / personas | NOT_RUN | No solicitados en este caso; no se ejecutaron Playwright, pruebas físicas ni estudios humanos |

`attempts.json` conserva los fallos iniciales y su resolución: cache npm incompleta; un nombre de prop que chocaba con `role` nativo, corregido a `occupation`; metadatos auxiliares del snapshot que afectaban a lint, retirados del árbol ejecutable. No se atribuyen estos metadatos al upstream ni al componente. Las sesiones de servidor se detuvieron; no queda una demo publicada.

Los scripts de contraste verifican solo los pares declarados. No cubren menús nativos del sistema, selección de texto ni todas las combinaciones de navegador. Bordes decorativos no se tratan como controles. El estado del encargo es entrega local implementada con verificación visual y de interacción pendiente.

`manifest.sha256.json` registra los archivos de esta entrega. No contiene `node_modules`, cache, logs npm completos ni snapshots del banco.
