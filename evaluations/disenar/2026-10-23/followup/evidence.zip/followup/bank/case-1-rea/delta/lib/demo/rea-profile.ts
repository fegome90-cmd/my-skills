// Perfil completamente sintético. No representa una persona ni una relación laboral real.
export const DEMO_REA_PROFILE = {
  name: "Alex Rivera",
  occupation: "Diseño de interfaces",
  location: "Valdivia, Chile · UTC−3",
  biography: "Conecta investigación, contenido y código para crear herramientas que se entiendan desde el primer uso.",
  skills: ["Sistemas de diseño", "Prototipado", "Accesibilidad"],
  details:
    "En este escenario ficticio, Alex colabora con equipos pequeños para documentar decisiones y convertir prototipos en interfaces mantenibles.",
};

export const DEMO_REA_PROFILE_LONG = {
  ...DEMO_REA_PROFILE,
  name: "Álex María Rivera de los Ríos — perfil sintético con nombre extenso",
  occupation: "Diseño, documentación y desarrollo de interfaces de información",
  location: undefined,
  skills: [
    "Documentación de sistemas complejos",
    "Internacionalización",
    "Investigación",
    "HTML semántico",
    "CSS",
    "TypeScript",
  ],
};
