"use client";

import { useState } from "react";
import { REA_PREVIEWS } from "@/components/docs/previews-rea";
import { type ReaAccent, ReaProvider, type ReaTheme } from "@/components/ui/rea/rea-theme";

const ProfilePreview = REA_PREVIEWS["rea-profile-card"];

export default function ProfileDemoPage() {
  const [theme, setTheme] = useState<ReaTheme>("light");
  const [accent, setAccent] = useState<ReaAccent>("blue");
  const selectClass =
    "min-h-[44px] border border-rea-control-line bg-rea-bg px-3 text-rea-ink focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-rea-ink";
  return (
    <ReaProvider theme={theme} accent={accent} surface className="min-h-screen p-[clamp(16px,4vw,48px)]">
      <main className="mx-auto grid max-w-[780px] gap-8">
        <header>
          <p className="m-0 font-rea-mono text-[0.75rem] uppercase">REA · componente candidato</p>
          <h1 className="mt-3 mb-4 text-rea-step-3 leading-[1] tracking-[-0.05em]">Tarjeta de perfil</h1>
          <p className="m-0">Selecciona contenido y apariencia. Abre los detalles y visita el contacto de ejemplo.</p>
        </header>
        <div className="flex flex-wrap gap-4">
          <label className="grid gap-2">
            Tema
            <select
              className={selectClass}
              value={theme}
              onChange={(event) => setTheme(event.target.value as ReaTheme)}
            >
              <option value="light">Claro</option>
              <option value="dark">Oscuro</option>
            </select>
          </label>
          <label className="grid gap-2">
            Acento
            <select
              className={selectClass}
              value={accent}
              onChange={(event) => setAccent(event.target.value as ReaAccent)}
            >
              <option value="blue">Azul</option>
              <option value="orange">Naranjo</option>
              <option value="lime">Lima</option>
            </select>
          </label>
        </div>
        <ProfilePreview />
      </main>
    </ReaProvider>
  );
}
