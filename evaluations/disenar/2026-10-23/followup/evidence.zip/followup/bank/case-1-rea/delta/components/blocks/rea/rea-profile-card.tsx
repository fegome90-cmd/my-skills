import type * as React from "react";
import { ReaButton } from "@/components/ui/rea/rea-button";
import { ReaNote } from "@/components/ui/rea/rea-note";
import { cn } from "@/lib/utils";

type ReaProfileCardProps = Omit<React.ComponentProps<"article">, "children"> & {
  name: string;
  occupation: string;
  location?: string;
  biography?: string;
  skills?: string[];
  details?: string;
  action?: { href: string; label: string };
  headingLevel?: 2 | 3;
};

/** Composición nueva con tokens y primitivas REA; no reproduce un perfil del sitio de referencia. */
function ReaProfileCard({
  name,
  occupation,
  location,
  biography,
  skills = [],
  details,
  action,
  headingLevel = 2,
  className,
  ...props
}: ReaProfileCardProps) {
  const Heading = `h${headingLevel}` as "h2" | "h3";
  const initials = name
    .trim()
    .split(/\s+/u)
    .slice(0, 2)
    .map((part) => Array.from(part)[0])
    .join("");
  return (
    <article
      data-slot="rea-profile-card"
      className={cn(
        "grid min-w-0 gap-6 border border-rea-line border-t-[3px] border-t-rea-accent bg-rea-bg p-[clamp(20px,4vw,36px)] text-rea-ink [overflow-wrap:anywhere]",
        className,
      )}
      {...props}
    >
      <header className="flex items-start gap-4">
        <span
          aria-hidden="true"
          className="grid size-[64px] shrink-0 place-items-center border border-rea-line-strong bg-rea-bg-raised font-rea-mono text-[1.2rem] uppercase"
        >
          {initials || "?"}
        </span>
        <div className="min-w-0">
          <ReaNote tone="ink">{occupation}</ReaNote>
          <Heading className="mt-1 mb-0 font-rea-sans text-rea-step-2 leading-[1.08] tracking-[-0.04em]">
            {name}
          </Heading>
          {location && <p className="mt-2 mb-0 text-[0.85rem] text-rea-muted">{location}</p>}
        </div>
      </header>
      {biography && <p className="m-0 max-w-[56ch] text-[1rem] leading-[1.65]">{biography}</p>}
      {skills.length > 0 && (
        <ul aria-label="Especialidades" className="m-0 flex list-none flex-wrap gap-2 p-0">
          {Array.from(new Set(skills)).map((skill) => (
            <li
              key={skill}
              className="rounded-full border border-rea-line-strong px-3 py-1.5 font-rea-mono text-[0.75rem]"
            >
              {skill}
            </li>
          ))}
        </ul>
      )}
      {details && (
        <details className="border-t border-rea-line pt-4">
          <summary className="min-h-[44px] cursor-pointer py-3 text-[0.9rem] font-medium focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-rea-ink">
            Más sobre {name}
          </summary>
          <p className="mt-3 mb-0 max-w-[56ch] text-[0.9rem] leading-[1.65]">{details}</p>
        </details>
      )}
      {action && (
        <ReaButton
          href={action.href}
          className="justify-self-start text-left whitespace-normal focus-visible:outline-rea-ink"
        >
          {action.label}
        </ReaButton>
      )}
    </article>
  );
}

export { ReaProfileCard, type ReaProfileCardProps };
